/* 
 * File:   compMoves.h
 * Author: Mathew Briguglio
 * Purpose: Header file for moving computer player's chess pieces
 * Created on May 2, 2015, 1:12 AM
 */

#ifndef COMPMOVES_H
#define	COMPMOVES_H

struct CompMoves
{
    char compPieces[8][8];                                                      // 2D array storing positions of computer's pieces on chess board. Each element stores a piece.
    char validMoves[8][8];                                                      // 2D array storing positions of computer's pieces that have legal moves on board.
    int *validPositions;                                                        // Dynamically allocated 1D array. Stores the positions of comp pieces, but the subscripts begin at 0.
};

#endif	/* COMPMOVES_H */