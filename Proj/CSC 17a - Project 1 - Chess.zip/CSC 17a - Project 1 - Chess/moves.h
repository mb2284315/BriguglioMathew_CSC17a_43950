/* 
 * File:   moves.h
 * Author: Mathew Briguglio
 * Purpose: Header file used to validate human player input
 * Created on May 2, 2015, 1:14 AM
 */

#ifndef MOVES_H
#define	MOVES_H

struct Moves                                                                    // Use this structure to make an array of structures. Each element of the array will contain the member
{                                                                               // variables left, right, forward, back, and diagonal. Every element represents a chess piece. This structure
    int left;                                                                   // can be used for the human player such that if they choose a piece it can be checked for available moves,
    int right;                                                                  // and if there are none, then it will ask them to move another piece. The computer doesn't need this
    int forward;                                                                // structure because it has a 2D array already storing its valid moves.
    int back;
    int diagonal;
};

#endif	/* MOVES_H */