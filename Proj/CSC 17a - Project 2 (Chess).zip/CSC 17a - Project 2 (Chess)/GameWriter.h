
#ifndef GAMEWRITER_H
#define	GAMEWRITER_H

using namespace std;

#include "FileWriter.h"

class GameWriter : public FileWriter  
{
    public:
        GameWriter(string);
        virtual ~GameWriter();
        void saveGame(string name, int num, int nthMove);
        void loadGame();
    private:
       char* name2;

};

#endif	/* GAMEWRITER_H */

