

#include "GameWriter.h"
#include <iostream>

GameWriter::GameWriter(string name) : FileWriter(name)
{}

GameWriter::~GameWriter() 
{
    delete this->name2;
}

void GameWriter::saveGame(string name, int num, int nthMove)
{
    this->name = name;
    this->name2 = (char*)this->name.c_str();
    
    cout << "Saving game...\n";
    cout << "Game saved.\n\n";
    
    this->file.open("chess.txt", ios::out | ios::binary);
    this->file.write(name2, sizeof(name2));
    
    this->file.write(reinterpret_cast<char *>(&nthMove), sizeof(nthMove));
    this->file.close();
}

// Implement function to continue a previous game. Pieces remain in the positions they were left in.
void GameWriter::loadGame()
{
    const int SIZE = 20;
    char chessData[SIZE];
    int nthMove;
    
    for (int count = 0; count < SIZE - 1; count++)
        chessData[count] = ' ';
    
    this->file.open("chess.txt", ios::in | ios::binary);
    
    this->file.read(chessData, sizeof(chessData));
    this->file.read(reinterpret_cast<char *>(&nthMove), sizeof(nthMove));
    
    cout << "Player Name: " << chessData << endl;
    cout << "Number of Moves: " << nthMove << endl << endl;
    
    this->file.close();
}