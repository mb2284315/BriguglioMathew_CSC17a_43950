
#include "FileWriter.h"
using namespace std;


FileWriter::FileWriter(string name)
{
    this->name = name;
}


FileWriter::~FileWriter() 
{
    
}

