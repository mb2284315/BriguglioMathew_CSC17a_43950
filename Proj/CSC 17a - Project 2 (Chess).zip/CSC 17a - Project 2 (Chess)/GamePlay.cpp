
#include "GamePlay.h"
#include <cstdlib>
#include <iostream>



GamePlay::GamePlay() 
{
    
}


GamePlay::~GamePlay()
{
    
}

// Implement function to determine if the player entered there own piece and entered its correct position on the board.
bool GamePlay::validatePos(char **chessPieces, char cur[], int num)
{
    // Moves p[] is the array of structures in which each element contains
    // the number of squares certain pieces can move in any direction.
    
    // QUESTION: Do I want to use the array of structures? It will over-complicate the code. ***************
    
    // cur[] is the currentAN array from newGame function.
    bool validation;
    int col, row;
    col = static_cast<int>(cur[1]) - 96;
    row = 57 - static_cast<int>(cur[2]);
    
        // Must translate the Algebraic Notation (AN) entered by player to the actual row and column 0-9 of 2D array.
        // To determine the position in the 2D array based on the column/file letter entered by the player                                                                        
        // realize that the chess board has *, a, b, c, d, ... which corresponds with 0, 1, 2, 3, 4, ... and that
        // a, b, c, etc, are 97, 98, 99, in the ASCII code. So, to get 0, 1, 2, etc you statically cast the letter
        // stored in currentAN[1] as an int and then subtract 96. This gives the column in the 2D array.
        
        // Next, to get the row in the 2D array, realize that the chess board has char variables *, 8, 7, 6, ... which
        // are changing in the opposite way of the actual subscripts of the 2D array. Also, the 8, 7, 6, ... are 
        // 56, 55, 54, ... in the ASCII code. So, to get 0, 1, 2, etc ... you take 57 and subtract the int value of
        // the digit they entered for the row - Ex. If they entered row 7, ASCII code for 7 is 55, and 57 - 55 = 2.
        // This gives the row in the 2D array.
    
    // Player chose black pieces.
    if (num == 1)
    {
        if (cur[0] == 'R' || cur[0] == 'N' || cur[0] == 'B' ||  cur[0] == 'Q' || cur[0] == 'K' ||  cur[0] == 'P')   // First, just check for an uppercase letter for the chess piece.
        {
            if (chessPieces[row][col] == cur[0])                                // Next, check if the piece in the position entered by player actually is the piece they entered.
                validation = true;
        }
        else if (cur[0] == 'c' && cur[1] == 'c' && cur[2] == 'c')               // Validation if player wants to castle with rook and king.
            validation = true;
        else
            validation = false;                                                 // If the player didn't enter an uppercase letter and the position doesn't contain the piece they
                                                                                // entered, then they need to change their input.
    }
    // Player chose white pieces.
    else if (num == 2)
    {
        if (cur[0] == 'r' || cur[0] == 'n' || cur[0] == 'b' ||  cur[0] == 'q' || cur[0] == 'k' ||  cur[0] == 'a')   // First, just check for a lowercase letter for the chess piece.
        {
            if (chessPieces[row][col] == cur[0])                                // Next, check if the piece in the position entered by player actually is the piece they entered.
                validation = true;
        }
        else
            validation = false;                                                 // If the player didn't enter a lowercase letter and the position doesn't contain the piece they
                                                                                // entered, then they need to change their input.
    }
    
    return validation;
}

bool GamePlay::validateMove(char **chessPieces, char cur[], char nex[], int num)
{
    // cur[] is currentAN array and nex[] is nextAN array from newGame function.
    // This function must determine which piece the player wants to move, and whether or not the move is valid.
    // Important: make sure pieces cannot move through other pieces. No pieces can be in the path of another piece.
    // So, if either the piece moves off the board or encounters another piece, then the initial piece must stop.
    // NOTE: I'm not ready for capturing pieces yet. For now, only moves where the player's chess piece cannot go through another piece.
    // What if the player enters their current position, but there isn't a valid move for the piece?
    // Won't the program just keep saying invalid move, and not let the user try to move a different piece?
    
    bool boolianL = false,                                                      // Used in while loop for rook.
         boolianR = false,                                                      // Used in while loop for rook.
         boolianB = false,
         boolianF = false,
         validation;                                                            // Returned to new game function. If true, move is valid. If false, move is invalid.
    
    int col, row;                                                               // Column and row positions in 2D chessPieces array.
    col = static_cast<int>(cur[1]) - 96;                                        // Column number in array where chess piece is currently (before move).
    row = 57 - static_cast<int>(cur[2]);                                        // Row number in array where chess piece is currently (before move).
    
    int colNext, rowNext;                                                       // Column and row positions in 2D chessPieces array.
    colNext = static_cast<int>(nex[1]) - 96;                                    // Column number player wants to move to.
    rowNext = 57 - static_cast<int>(nex[2]);                                    // Row number player wants to move to.
    
    int colL,                                                                   // colL (column left) is used to determine how many spaces a piece can move to the left.
        colR,                                                                   // colR (column right) is used to determine how many spaces a piece can move to the right.
        rowF,                                                                   // rowF (row forward) is used to determine how many squares a piece can move forward.
        rowB,                                                                   // rowB (row Backward) is used to determine how many squares a piece can move backward.
        leftMost,                                                               // Max number of squares a piece can move to the left.
        rightMost,                                                              // Max number of squares a piece can move to the right.
        forwardMost,                                                            // Max number of squares a piece can move forward.
        backMost;                                                               // Max number of squares a piece can move backward.
    // Black pieces.
    if (num == 1)
    {
        if (cur[0] == nex[0] && (cur[1] != nex[1] || cur[2] != nex[2]) && 
            colNext > 0 && colNext < 9 && rowNext > 0 && rowNext < 9)
        {                                                                       // First, make sure the player entered the same piece and either the column or the row is different
                                                                                // in the nextAN array from the currentAN array. Also, make sure the row or column is on the board.
            if (cur[0] == 'P')                                                  // Validate moves for a pawn.
            {
                if (row == 7)            
                {
                    if (!isalpha(chessPieces[row - 1][col]) && nex[1] == cur[1] && nex[2] == cur[2] + 1)
                        validation = true;                                      // If no pieces one square up from pawn and player wants to move one square up, then valid move.
                    else if (!isalpha(chessPieces[row - 1][col]) && !isalpha(chessPieces[row - 2][col]) && nex[1] == cur[1] && nex[2] == cur[2] + 2)
                            validation = true;                                  // If no pieces one or two squares up from pawn and player wants to move two squares up, then valid move.
                    else if (islower(chessPieces[row - 1][col - 1]) && nex[1] == cur[1] - 1 && nex[2] == cur[2] + 1) // Player wants to capture up and to left.
                        validation = true;
                    else if (islower(chessPieces[row - 1][col + 1]) && nex[1] == cur[1] + 1 && nex[2] == cur[2] + 1) // Player wants to capture up and to right
                        validation = true;
                }
                else if (row != 7)
                {
                    if (!isalpha(chessPieces[row - 1][col]) && nex[1] == cur[1] && nex[2] == cur[2] + 1)
                        validation = true;                                      // If no pieces one square up from pawn and player wants to move one square up, then valid move.
                    else if (islower(chessPieces[row - 1][col - 1]) && nex[1] == cur[1] - 1 && nex[2] == cur[2] + 1) // Player wants to capture up and to left.
                        validation = true;
                    else if (islower(chessPieces[row - 1][col + 1]) && nex[1] == cur[1] + 1 && nex[2] == cur[2] + 1) // Player wants to capture up and to right
                        validation = true;
                    // Need an else if statement for en passant move.
                }
            }
            else if (cur[0] == 'R')
            {
                // Rook has max of 4 directional options. Column will tell you how many squares left or right rook can move.
                // Row will tell you how many squares forward or back rook can move.
                
                if (nex[2] == cur[2] && nex[1] != cur[1])                       // If player wants to keep rook in same row, but move to a different column.
                {
                    colL = col;                                                 // Initialize both colL and colR to the value in col.
                    colR = col;                                                 // By doing this, colL can be decremented and colR can be incremented, simultaneously.
                    while (boolianL == false)
                    {
                        colL--;
                        if (isalpha(chessPieces[row][colL]) || colL == 0)       // If this new column has a piece in it or if the column is 0.
                        {
                            if (isupper(chessPieces[row][colL]) || colL == 0)
                                leftMost = colL + 1;                            // The furthest to the left that the rook can move. (With another black piece next to it.)
                            else if (islower(chessPieces[row][colL]))           // Rook can capture the piece blocking its path.
                                leftMost = colL;
                            boolianL = true;                                    // Once leftMost value is found, boolianL is assigned the value true and loop terminates.
                        }
                    }
                    while (boolianR == false)
                    {
                        colR++;
                        if (isalpha(chessPieces[row][colR]) || colR == 9)       // If this new column has a piece in it or if the column is 9.
                        { 
                            if (isupper(chessPieces[row][colR]) || colR == 9)
                                rightMost = colR - 1;                           // The furthest to the right that the rook can move. (With another black piece next to it.)
                            else if (islower(chessPieces[row][colR]))           // Rook can capture the piece blocking its path.
                                rightMost = colR;
                            boolianR = true;                                    // Once rightMost value is found, boolianR is assigned the value true and loop terminates.
                        }
                    }
                    if (colNext >= leftMost && colNext <= rightMost)            // Now check whether nex[1] (column player wants to move to) is b/t leftMost and rightMost.
                        validation = true;                                      // If column they want is between the values, then valid move.
                }
                else if (nex[1] == cur[1] && nex[2] != cur[2])                  // If player wants to keep rook in same column, but move to a different row.
                {
                    // Using same variables for counting max square the rook
                    // can move forward and backward. Should say rowF/rowB.
                    rowB = row;                                                 // Initialize both colL and colR to the value in row. I'm using colL and colR as the row numbers!!!
                    rowF = row;                                                 // By doing this, colL can be decremented and colR can be incremented, simultaneously.
                    while (boolianF == false)
                    {
                        // Decrement row is going up the board - so forward.
                        rowF--;
                        if (isalpha(chessPieces[rowF][col]) || rowF == 0)       // If this new row has a piece in it or if the row is 0.
                        {
                            if (isupper(chessPieces[rowF][col]) || rowF == 0)
                                forwardMost = rowF + 1;                         // The furthest that the rook can move forward. (Toward top of board - closer to row 0 - so smaller value for row.)
                            else if (islower(chessPieces[rowF][col]))           // Rook can capture piece blocking its way.
                                forwardMost = rowF;
                            boolianF = true;                                    // Once forwardMost value is found, boolianF is assigned the value true and loop terminates.
                        }
                    }
                    while (boolianB == false)
                    {
                        rowB++;
                        if (isalpha(chessPieces[rowB][col]) || rowB == 9)       // If this new row has a piece in it or if the row is 9.
                        { 
                            if (isupper(chessPieces[rowB][col]) || rowB == 9)
                                backMost = rowB - 1;                            // The furthest that the rook can move backward. (Toward bottom of board - closer to row 9 - so larger value for row.)
                            else if (islower(chessPieces[rowB][col]))           // Rook can capture piece blocking its way.
                                backMost = rowB;
                            boolianB = true;                                    // Once rightMost value is found, boolianR is assigned the value true and loop terminates.
                        }
                    }
                    if (rowNext >= forwardMost && rowNext <= backMost)          // Now check whether nex[1] (column player wants to move to) is b/t backMost and forwardMost.
                        validation = true;                                      // Note: forwardMost is actually smaller row number and backMost is larger row number.
                                                                                // If column they want is between the values, then valid move.
                }
            }
            else if (cur[0] == 'N')
                validation = true;
            else if (cur[0] == 'B')
                validation = true;
            else if (cur[0] == 'Q')
                validation = true;
            else if (cur[0] == 'K')
                validation = true;
        } // Next are special moves: castling and en passant. Note: A lot of options for en passant.
        else if (nex[0] == 'c' && nex[1] == 'c' && nex[2] == 'c' && cur[1] == 'a' && cur[2] == '1' && chessPieces[8][5] == 'K'// Rook/king must be in original positions (and must not have been moved)
                 && !isalpha(chessPieces[8][2]) && !isalpha(chessPieces[8][3]) && !isalpha(chessPieces[8][4]))                // Cannot be any pieces between rook and king. (Rook on left side of board)
            validation = true;
        else if (nex[0] == 'c' && nex[1] == 'c' && nex[2] == 'c' && cur[1] == 'h' && cur[2] == '1' && chessPieces[8][5] == 'K'
                 && !isalpha(chessPieces[8][7]) && !isalpha(chessPieces[8][6]))                                        // Cannot be any pieces between rook and king. (Rook on right side of board)
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'a' && chessPieces[4][2] == 'a' // Following else if statements for en passant to right.
                 && !isalpha(chessPieces[3][2]))                                // For en passant, pawn position must be col a-h and row 5. There must be an opponent's pawn in adjacent square.
            validation = true;                                                  // There must also be no piece immediately behind the opponent's pawn. Also pawn may en passant to left or right.
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'b' && chessPieces[4][3] == 'a'
                 && !isalpha(chessPieces[3][3]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'c' && chessPieces[4][4] == 'a'
                 && !isalpha(chessPieces[3][4]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'd' && chessPieces[4][5] == 'a'
                 && !isalpha(chessPieces[3][5]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'e' && chessPieces[4][6] == 'a'
                 && !isalpha(chessPieces[3][6]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'f' && chessPieces[4][7] == 'a'
                 && !isalpha(chessPieces[3][7]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'g' && chessPieces[4][8] == 'a'
                 && !isalpha(chessPieces[3][8]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'b' && chessPieces[4][1] == 'a' // Following else if statements for en passant to left.
                 && !isalpha(chessPieces[3][1]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'c' && chessPieces[4][2] == 'a'
                 && !isalpha(chessPieces[3][2]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'd' && chessPieces[4][3] == 'a'
                 && !isalpha(chessPieces[3][3]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'e' && chessPieces[4][4] == 'a'
                 && !isalpha(chessPieces[3][4]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'f' && chessPieces[4][5] == 'a'
                 && !isalpha(chessPieces[3][5]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'g' && chessPieces[4][6] == 'a'
                 && !isalpha(chessPieces[3][6]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'P' && cur[2] == '5' && cur[1] == 'h' && chessPieces[4][7] == 'a'
                 && !isalpha(chessPieces[3][7]))
            validation = true;
        else
            validation = false;
    }
    // White pieces.
    else if (num == 2)
    {
        if (cur[0] == nex[0] && (cur[1] != nex[1] || cur[2] != nex[2]) && colNext > 0 && colNext < 9 && rowNext > 0 && rowNext < 9)
        {                                                                       // First, make sure the player entered the same piece and either the column or the row is different
                                                                                // in the nextAN array from the currentAN array. Also, make sure the row or column is on the board.
            if (cur[0] == 'a')                                                  // Validate moves for a pawn.
            {   
                if (row == 7)            
                {
                    if (!isalpha(chessPieces[row - 1][col]) && nex[1] == cur[1] && nex[2] == cur[2] + 1)
                        validation = true;                                      // If no pieces one square up from pawn and player wants to move one square up, then valid move.
                    else if (!isalpha(chessPieces[row - 1][col]) && !isalpha(chessPieces[row - 2][col]) && nex[1] == cur[1] && nex[2] == cur[2] + 2)
                            validation = true;                                  // If no pieces one or two squares up from pawn and player wants to move two squares up, then valid move.
                    else if (isupper(chessPieces[row - 1][col - 1]) && nex[1] == cur[1] - 1 && nex[2] == cur[2] + 1) // Player wants to capture up and to left.
                        validation = true;
                    else if (isupper(chessPieces[row - 1][col + 1]) && nex[1] == cur[1] + 1 && nex[2] == cur[2] + 1) // Player wants to capture up and to right
                        validation = true;
                }
                else if (row != 7)
                {
                    if (!isalpha(chessPieces[row - 1][col]) && nex[1] == cur[1] && nex[2] == cur[2] + 1)
                        validation = true;                                      // If no pieces one square up from pawn and player wants to move one square up, then valid move.
                    else if (isupper(chessPieces[row - 1][col - 1]) && nex[1] == cur[1] - 1 && nex[2] == cur[2] + 1) // Player wants to capture up and to left.
                        validation = true;
                    else if (isupper(chessPieces[row - 1][col + 1]) && nex[1] == cur[1] + 1 && nex[2] == cur[2] + 1) // Player wants to capture up and to right
                        validation = true;
                    // Need an else if statement for en passant move.
                }
            }
            else if (cur[0] == 'r')
            {
               // Rook has max of 4 directional options. Column will tell you how many squares left or right rook can move.
                // Row will tell you how many squares forward or back rook can move.
                
                if (nex[2] == cur[2] && nex[1] != cur[1])                       // If player wants to keep rook in same row, but move to a different column.
                {
                    colL = col;                                                 // Initialize both colL and colR to the value in col.
                    colR = col;                                                 // By doing this, colL can be decremented and colR can be incremented, simultaneously.
                    while (boolianL == false)
                    {
                        colL--;
                        if (isalpha(chessPieces[row][colL]) || colL == 0)       // If this new column has a piece in it or if the column is 0.
                        {
                            if (islower(chessPieces[row][colL]) || colL == 0)
                                leftMost = colL + 1;                            // The furthest to the left that the rook can move. (With another black piece next to it.)
                            else if (isupper(chessPieces[row][colL]))           // Rook can capture the piece blocking its path.
                                leftMost = colL;
                            boolianL = true;                                    // Once leftMost value is found, boolianL is assigned the value true and loop terminates.
                        }
                    }
                    while (boolianR == false)
                    {
                        colR++;
                        if (isalpha(chessPieces[row][colR]) || colR == 9)       // If this new column has a piece in it or if the column is 9.
                        { 
                            if (islower(chessPieces[row][colR]) || colR == 9)
                                rightMost = colR - 1;                           // The furthest to the right that the rook can move. (With another black piece next to it.)
                            else if (isupper(chessPieces[row][colR]))           // Rook can capture the piece blocking its path.
                                rightMost = colR;
                            boolianR = true;                                    // Once rightMost value is found, boolianR is assigned the value true and loop terminates.
                        }
                    }
                    if (colNext >= leftMost && colNext <= rightMost)            // Now check whether nex[1] (column player wants to move to) is b/t leftMost and rightMost.
                        validation = true;                                      // If column they want is between the values, then valid move.
                }
                else if (nex[1] == cur[1] && nex[2] != cur[2])                  // If player wants to keep rook in same column, but move to a different row.
                {
                    rowB = row;
                    rowF = row;
                    while (boolianF == false)
                    {
                        // Decrement row is going up the board - so forward.
                        rowF--;
                        if (isalpha(chessPieces[rowF][col]) || rowF == 0)       // If this new row has a piece in it or if the row is 0.
                        {
                            if (isupper(chessPieces[rowF][col]))
                                forwardMost = rowF;                             // The furthest that the rook can move forward. (Toward top of board - closer to row 0 - so smaller value for row.)
                            else if (islower(chessPieces[rowF][col]) || rowF == 0) // Rook can capture piece blocking its way.
                                forwardMost = rowF + 1;
                            boolianF = true;                                    // Once forwardMost value is found, boolianF is assigned the value true and loop terminates.
                        }
                    }
                    while (boolianB == false)
                    {
                        rowB++;
                        if (isalpha(chessPieces[rowB][col]) || rowB == 9)       // If this new row has a piece in it or if the row is 9.
                        { 
                            if (islower(chessPieces[rowB][col]) || rowB == 9)
                                backMost = rowB - 1;                            // The furthest that the rook can move backward. (Toward bottom of board - closer to row 9 - so larger value for row.)
                            else if (isupper(chessPieces[rowB][col]))           // Rook can capture piece blocking its way.
                                backMost = rowB;
                            boolianB = true;                                    // Once rightMost value is found, boolianR is assigned the value true and loop terminates.
                        }
                    }
                    if (rowNext >= forwardMost && rowNext <= backMost)          // Now check whether nex[1] (column player wants to move to) is b/t backMost and forwardMost.
                        validation = true;                                      // Note: forwardMost is actually smaller row number and backMost is larger row number.
                                                                                // If column they want is between the values, then valid move.
                }
                // Need an else if statement for castle move with king. Use a special symbol for castle move. If that symbol is entered, the validation will allow it.
            }
            else if (cur[0] == 'n')
                validation = true;
            else if (cur[0] == 'b')
                validation = true;
            else if (cur[0] == 'q')
                validation = true;
            else if (cur[0] == 'k')
                validation = true;
        } // Next are special moves: castling and en passant.
        else if (nex[0] == 'c' && nex[1] == 'c' && nex[2] == 'c' && chessPieces[8][1] == 'r' && chessPieces[8][5] == 'k' // Rook and king must be in original positions (and must not have been moved)
                 && !isalpha(chessPieces[8][2]) && !isalpha(chessPieces[8][3]) && !isalpha(chessPieces[8][4]))  // Cannot be any pieces between rook and king. (Rook on left side of board)
            validation = true;
        else if (nex[0] == 'c' && nex[1] == 'c' && nex[2] == 'c' && chessPieces[8][8] == 'r' && chessPieces[8][5] == 'k'
                 && !isalpha(chessPieces[8][7]) && !isalpha(chessPieces[8][6]))     // Cannot be any pieces between rook and king. (Rook on right side of board)
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'a' && chessPieces[4][2] == 'P' // Following else if statements for en passant to right.
                 && !isalpha(chessPieces[3][2]))                                // For en passant, pawn position must be col a-h and row 5. There must be an opponent's pawn in adjacent square.
            validation = true;                                                  // There must also be no piece immediately behind the opponent's pawn. Also pawn may en passant to left or right.
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'b' && chessPieces[4][3] == 'P'
                 && !isalpha(chessPieces[3][3]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'c' && chessPieces[4][4] == 'P'
                 && !isalpha(chessPieces[3][4]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'd' && chessPieces[4][5] == 'P'
                 && !isalpha(chessPieces[3][5]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'e' && chessPieces[4][6] == 'P'
                 && !isalpha(chessPieces[3][6]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'f' && chessPieces[4][7] == 'P'
                 && !isalpha(chessPieces[3][7]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'r' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'g' && chessPieces[4][8] == 'P'
                 && !isalpha(chessPieces[3][8]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'b' && chessPieces[4][1] == 'P' // Following else if statements for en passant to left.
                 && !isalpha(chessPieces[3][1]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'c' && chessPieces[4][2] == 'P'
                 && !isalpha(chessPieces[3][2]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'd' && chessPieces[4][3] == 'P'
                 && !isalpha(chessPieces[3][3]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'e' && chessPieces[4][4] == 'P'
                 && !isalpha(chessPieces[3][4]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'f' && chessPieces[4][5] == 'P'
                 && !isalpha(chessPieces[3][5]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'g' && chessPieces[4][6] == 'P'
                 && !isalpha(chessPieces[3][6]))
            validation = true;
        else if (nex[0] == 'p' && nex[1] == 'p' && nex[2] == 'l' && cur[0] == 'a' && cur[2] == '5' && cur[1] == 'h' && chessPieces[4][7] == 'P'
                 && !isalpha(chessPieces[3][7]))
            validation = true;
        else
            validation = false;
    }
    
    return validation;
}
// All I have to do is update compPiece array and then bring the structure containing it 
// back through this function throughout game and every time function is called validMoves array will be updated. Right?
int* GamePlay::getCompMove(char **piece, CompMoves &computer, int num, int nthMove)
{
    const int SIZE = 4;
    int  rank,                                                                  // The rows on a chess board are called ranks.
         file,                                                                  // The columns on a chess board are called files.
         pieceNumber = 0,                                                       // The nth piece that has a valid move in the validMoves array.
         numValid = 0,                                                          // Number of pieces that have legal moves.
         choice,                                                                // The randomly selected piece that the computer will move.
         positionsArray[SIZE],                                                  // Array holding the rows and columns.
        *piecePositions;                                                        // pointer storing former and new rows and columns.
    
    bool valid = false;
    
    for (int row = 1; row < 9; row++)
    {
        for (int col = 1; col < 9; col++)
            computer.validMoves[row][col] = '0';                                // At beginning of game store a 0 in every element of validMoves 2D array to indicate pieces that cannot be moved.
    }
    
    for (int row = 1; row < 9; row++)                                           // All elements of validMoves array were initialized to 0. Now this for loop will find pieces that have moves and store
    {                                                                           // those pieces in the validMoves array using the subscripts that denote their position.
        for (int col = 1; col < 9; col++)
        {
            if (computer.compPieces[row][col] != '0')
            {
                valid = findValidMoves(piece, computer, row, col, num);
                if (valid == true)
                {
                    computer.validMoves[row][col] = computer.compPieces[row][col];
                    numValid++;                                                 // Increment the number of pieces with valid moves.
                }
                
            }
        }
    }
    
    // Put the positions of the pieces having valid moves into another array. Have the row number stored in
    // one element and the column number stored in the next element. This array would have to be dynamically
    // allocated because the number of valid moves changes throughout the game. The number of pieces that have
    // available moves can be found by counting the number of times the findValidMoves function returns true.
    // Then that number will be doubled since the one array must hold the row and column numbers of each piece.
    
    numValid = numValid*2;                                                      // Reassign numValid to twice the value.
    
    computer.validPositions = new int[numValid];                                // Dynamically allocate memory to pointer internal to CompMoves structure
                                                                                // The 0th subscript of validPieces array is the row number of a piece, the 1st is a column number.
                                                                                // Thus, every even numbered subscript stores a row number and every odd numbered subscript stores a column number.
    for (int row = 1; row < 9; row ++)
    {
        for (int col = 1; col < 9; col++)                                       // Note: validMoves array stores the pieces that the computer can move, and the row and column numbers represent
        {                                                                       // that specific piece's position on the chess board. I'm taking the row and column numbers of these pieces
            if (isalpha(computer.validMoves[row][col]))                         // and storing them next to each other in a 1D array. Then one of those row or column numbers is randomly
            {                                                                   // selected and that row or column number will give the other, and the piece can be determined and moved!
                computer.validPositions[pieceNumber] = row;                     // An even subscript in validPieces array stores the row number.
                computer.validPositions[pieceNumber + 1] = col;                 // The next subscript, an odd one, in validPieces array stores the column number.
                pieceNumber = pieceNumber + 2;
            }                                                                   // Also, the validMoves array either contains the computer's pieces (whatever they were in the beginning)
        }                                                                       // or a 0. So, all that has to be checked is that it is a letter of the alphabet in if statement.
    }
    
    unsigned seed = time(0);
    srand(seed);
    
    // Suppose there are 3 pieces on the board with valid moves. Since each piece has a position
    // described by a row and a column, there are 2 values associated with each of the 3 pieces.
    // This means 6 elements. However, the validPieces array begins with subscript 0, so 0-5 is used
    // to store the 6 row and column numbers of the pieces. pieceNumber would hold the number 6 in
    // this case. Below, a number between 0 and pieceNumber - 1 is randomly generated and stored
    // in the variable choice. This is perfect since choice must be between 0 and 5.
    
    choice = rand() % pieceNumber;                                              // choice stores the row or column number of a valid move.
    
    if (choice % 2 == 0)                                                        // choice is even and this element in the validPieces array holds a row number.
    {
        rank = computer.validPositions[choice];                                 // The rows on a chess board are called ranks.
        file = computer.validPositions[choice + 1];                             // Since choice is even, the element holds a row number. The next element in validPieces array must be a column number.
    }
    else if (choice % 2 == 1)                                                   // choice is odd and the element holds a column number.
    {
        rank = computer.validPositions[choice - 1];                             // Since choice odd, element holds a column number. The previous element in the validPieces array must be a row number.
        file = computer.validPositions[choice];                                 // The columns on a chess board are called files. choice is odd, so the element is a column, or file.
    }
    
    // Note: By finding rank and file, I've only determined the position of the
    // piece that will be moved, but I haven't found out where it will be moved.
    
    piecePositions = positionsArray;                                            // Have pointer point to positionsArray array. QUESTION: Do I have to point to an array to return values stored in it?
    
    piecePositions = moveCompPiece(piece, computer, rank, file, num);           // Call function that actually moves piece and displays updated chessboard. It also returns pointer with positions.
    
    delete [] computer.validPositions;                                          // Free the memory.
    computer.validPositions = 0;
           
    return piecePositions;
}

bool GamePlay::findValidMoves(char **piece, CompMoves &c, int row, int col, int num)
{
    bool validMove = false;
    
    if (c.compPieces[row][col] == 'P' || c.compPieces[row][col] == 'a')
    {
        if (row == 2 && !isalpha(piece[row + 1][col]) && !isalpha(piece[row + 2][col]) && row + 2 < 9)
            validMove = true;
        else if (!isalpha(piece[row + 1][col]) && row + 1 < 9)
            validMove = true;
        else if (num == 1 && isupper(piece[row + 1][col + 1]) && row + 1 < 9 && col + 1 < 9)
            validMove = true;
        else if (num == 1 && isupper(piece[row + 1][col - 1]) && row + 1 < 9 && col - 1 > 0)
            validMove = true;
        else if (num == 2 && islower(piece[row + 1][col + 1]))
            validMove = true;
        else if (num == 2 && islower(piece[row + 1][col - 1]))
            validMove = true;
    }
    else if (c.compPieces[row][col] == 'N' || c.compPieces[row][col] == 'n')
    {
        if (num == 1 && row - 2 > 0 && col + 1 < 9 && !islower(piece[row - 2][col + 1]))
            validMove = true;
        else if (num == 1 && row - 2 > 0 && col - 1 > 0 && !islower(piece[row - 2][col - 1]))
            validMove = true;
        else if (num == 1 && row + 2 < 9 && col - 1 > 0 && !islower(piece[row + 2][col - 1]))
            validMove = true;
        else if (num == 1 && row + 2 < 9 && col + 1 < 9 && !islower(piece[row + 2][col + 1]))
            validMove = true;
        else if (num == 1 && row - 1 > 0 && col - 2 > 0 && !islower(piece[row - 1][col - 2]))
            validMove = true;
        else if (num == 1 && row + 1 < 9 && col - 2 > 0 && !islower(piece[row + 1][col - 2]))
            validMove = true;
        else if (num == 1 && row - 1 > 0 && col + 2 > 0 && !islower(piece[row - 1][col + 2]))
            validMove = true;
        else if (num == 1 && row + 1 < 9 && col + 2 > 0 && !islower(piece[row + 1][col + 2]))
            validMove = true;
        else if (num == 2 && row - 2 > 0 && col + 1 < 9 && !isupper(piece[row - 2][col + 1]))
            validMove = true;
        else if (num == 2 && row - 2 > 0 && col - 1 > 0 && !isupper(piece[row - 2][col - 1]))
            validMove = true;
        else if (num == 2 && row + 2 < 9 && col - 1 > 0 && !isupper(piece[row + 2][col - 1]))
            validMove = true;
        else if (num == 2 && row + 2 < 9 && col + 1 < 9 && !isupper(piece[row + 2][col + 1]))
            validMove = true;
        else if (num == 2 && row - 1 > 0 && col - 2 > 0 && !isupper(piece[row - 1][col - 2]))
            validMove = true;
        else if (num == 2 && row + 1 < 9 && col - 2 > 0 && !isupper(piece[row + 1][col - 2]))
            validMove = true;
        else if (num == 2 && row - 1 > 0 && col + 2 > 0 && !isupper(piece[row - 1][col + 2]))
            validMove = true;
        else if (num == 2 && row + 1 < 9 && col + 2 > 0 && !isupper(piece[row + 1][col + 2]))
            validMove = true;
    }
    else if (c.compPieces[row][col] == 'K' || c.compPieces[row][col] == 'k' || c.compPieces[row][col] == 'Q' || c.compPieces[row][col] == 'q')
    {
        // Giving the king and queen same moves for now, just when checking for a valid move. This
        // is because if the queen can move even one square in any direction, then there is a valid move.
        
        // The king moves are actually tricky because you'd have to check whether any
        // of the opponent's pieces can capture the king in his new position.*********************************************
        if (num == 1 && row - 1 > 0 && col - 1 > 0 && !islower(piece[row - 1][col - 1]))
            validMove = true;
        else if (num == 1 && row - 1 > 0 && !islower(piece[row - 1][col]))
            validMove = true;
        else if (num == 1 && row - 1 > 0 && col + 1 < 9 && !islower(piece[row - 1][col + 1]))
            validMove = true;
        else if (num == 1 && col - 1 > 0 && !islower(piece[row][col - 1]))
            validMove = true;
        else if (num == 1 && col + 1 < 9 && !islower(piece[row][col + 1]))
            validMove = true;
        else if (num == 1 && row + 1 < 9 && col - 1 > 0 && !islower(piece[row + 1][col - 1]))
            validMove = true;
        else if (num == 1 && row + 1 < 9 && !islower(piece[row + 1][col]))
            validMove = true;
        else if (num == 1 && row + 1 < 9 && col + 1 < 9 && !islower(piece[row + 1][col + 1]))
            validMove = true;
        else if (num == 2 && row - 1 > 0 && col - 1 > 0 && !isupper(piece[row - 1][col - 1]))
            validMove = true;
        else if (num == 2 && row - 1 > 0 && !isupper(piece[row - 1][col]))
            validMove = true;
        else if (num == 2 && row - 1 > 0 && col + 1 < 9 && !isupper(piece[row - 1][col + 1]))
            validMove = true;
        else if (num == 2 && col - 1 > 0 && !isupper(piece[row][col - 1]))
            validMove = true;
        else if (num == 2 && col + 1 < 9 && !isupper(piece[row][col + 1]))
            validMove = true;
        else if (num == 2 && row + 1 < 9 && col - 1 > 0 && !isupper(piece[row + 1][col - 1]))
            validMove = true;
        else if (num == 2 && row + 1 < 9 && !isupper(piece[row + 1][col]))
            validMove = true;
        else if (num == 2 && row + 1 < 9 && col + 1 < 9 && !isupper(piece[row + 1][col + 1]))
            validMove = true;
    }
    else if (c.compPieces[row][col] == 'B' || c.compPieces[row][col] == 'b')
    {
        if (num == 1 && row - 1 > 0 && col - 1 > 0 && !islower(piece[row - 1][col - 1]))
            validMove = true;
        else if (num == 1 && row - 1 > 0 && col + 1 < 9 && !islower(piece[row - 1][col + 1]))
            validMove = true;
        else if (num == 1 && row + 1 < 9 && col + 1 < 9 && !islower(piece[row + 1][col + 1]))
            validMove = true;
        else if (num == 1 && row + 1 < 9 && col - 1 > 0 && !islower(piece[row + 1][col - 1]))
            validMove = true;
        else if (num == 2 && row - 1 > 0 && col - 1 > 0 && !isupper(piece[row - 1][col - 1]))
            validMove = true;
        else if (num == 2 && row - 1 > 0 && col + 1 < 9 && !isupper(piece[row - 1][col + 1]))
            validMove = true;
        else if (num == 2 && row + 1 < 9 && col - 1 > 0 && !isupper(piece[row + 1][col - 1]))
            validMove = true;
        else if (num == 2 && row + 1 < 9 && col + 1 < 9 && !isupper(piece[row + 1][col + 1]))
            validMove = true;
    }
    else if (c.compPieces[row][col] == 'R' || c.compPieces[row][col] == 'r')
    {
        if (num == 1 && row - 1 > 0 && !islower(piece[row - 1][col]))
            validMove = true;
        else if (num == 1 && row + 1 < 9 && !islower(piece[row + 1][col]))
            validMove = true;
        else if (num == 1 && col + 1 < 9 && !islower(piece[row][col + 1]))
            validMove = true;
        else if (num == 1 && col - 1 > 0 && !islower(piece[row][col - 1]))
            validMove = true;
        else if (num == 2 && row + 1 < 9 && !isupper(piece[row + 1][col]))
            validMove = true;
        else if (num == 2 && row - 1 > 0 && !isupper(piece[row - 1][col]))
            validMove = true;
        else if (num == 2 && col + 1 < 9 && !isupper(piece[row][col + 1]))
            validMove = true;
        else if (num == 2 && col - 1 > 0 && !isupper(piece[row][col - 1]))
            validMove = true;
    }
    // Still need rook to castle.
    
    return validMove;
}

int* GamePlay::moveCompPiece(char **piece, CompMoves &c, int rank, int file, int num)
{
    int moveNum,                                                                // The random number generated that chooses a move from the move choices.
        newRank,                                                                // Row number of piece after move.
        newFile;                                                                // Column number of piece after move.
        
                                                                                // It will point to an address that store the row and column numbers of the original position and new
                                                                                // position of the piece that was moved.
    const int SIZE = 4;
    int rowsCols[SIZE];                                                         // rowsCols array stores the former row and column of the piece, and the new row and column of the piece.
    int *positions;                                                             // pointer to an int will be returned to getCompMove and will then be returned to newGame function.
    positions = rowsCols;                                                       // Going to return this pointer to an array.
    
    if (c.validMoves[rank][file] == 'P' || c.validMoves[rank][file] == 'a')     // validPieces array is 1D holding rows and columns; validMoves array is 2D and holds the piece in the row/column.
    {
        // Not randomizing the selection yet because not all moves are valid, but
        // definitely one move is valid for this piece if the rank/column were chosen.
        //unsigned seed = time(0);
        //srand(seed);
        //moveNum = 1 + rand() % 6;
        
        if (rank == 2 && !isalpha(piece[rank + 1][file]) && !isalpha(piece[rank + 2][file]))
        {
            newRank = rank + 2;
            newFile = file;
        }
        else if (!isalpha(piece[rank + 1][file]) && rank + 1 < 9)
        {
            newRank = rank + 1;
            newFile = file;
        }
        else if (num == 1 && isupper(piece[rank + 1][file + 1]) && rank + 1 < 9 && file + 1 < 9)
        {
            newRank = rank + 1;
            newFile = file + 1;
        }
        else if (num == 1 && isupper(piece[rank + 1][file - 1]) && rank + 1 < 9 && file - 1 > 0)
        {
            newRank = rank + 1;
            newFile = file - 1;
        }
        else if (num == 2 && islower(piece[rank + 1][file + 1]))
        {
            newRank = rank + 1;
            newFile = file + 1;
        }
        else if (num == 2 && islower(piece[rank + 1][file - 1]))
        {
            newRank = rank + 1;
            newFile = file - 1;
        }
    }
    else if (c.validMoves[rank][file] == 'N' || c.validMoves[rank][file] == 'n')
    {
        if (num == 1 && rank - 2 > 0 && file + 1 < 9 && !islower(piece[rank - 2][file + 1]))
        {
            newRank = rank - 2;
            newFile = file + 1;
        }
        else if (num == 1 && rank - 2 > 0 && file - 1 > 0 && !islower(piece[rank - 2][file - 1]))
        {
            newRank = rank - 2;
            newFile = file - 1;
        }
        else if (num == 1 && rank + 2 < 9 && file - 1 > 0 && !islower(piece[rank + 2][file - 1]))
        {
            newRank = rank + 2;
            newFile = file - 1;
        }
        else if (num == 1 && rank + 2 < 9 && file + 1 < 9 && !islower(piece[rank + 2][file + 1]))
        {
            newRank = rank + 2;
            newFile = file + 1;
        }
        else if (num == 1 && rank - 1 > 0 && file - 2 > 0 && !islower(piece[rank - 1][file - 2]))
        {
            newRank = rank - 1;
            newFile = file - 2;
        }
        else if (num == 1 && rank + 1 < 9 && file - 2 > 0 && !islower(piece[rank + 1][file - 2]))
        {
            newRank = rank + 1;
            newFile = file - 2;
        }
        else if (num == 1 && rank - 1 > 0 && file + 2 > 0 && !islower(piece[rank - 1][file + 2]))
        {
            newRank = rank - 1;
            newFile = file + 2;
        }
        else if (num == 1 && rank + 1 < 9 && file + 2 > 0 && !islower(piece[rank + 1][file + 2]))
        {
            newRank = rank + 1;
            newFile = file + 2;
        }
        else if (num == 2 && rank - 2 > 0 && file + 1 < 9 && !isupper(piece[rank - 2][file + 1]))
        {
            newRank = rank - 2;
            newFile = file + 1;
        }
        else if (num == 2 && rank - 2 > 0 && file - 1 > 0 && !isupper(piece[rank - 2][file - 1]))
        {
            newRank = rank - 2;
            newFile = file - 1;
        }
        else if (num == 2 && rank + 2 < 9 && file - 1 > 0 && !isupper(piece[rank + 2][file - 1]))
        {
            newRank = rank + 2;
            newFile = file - 1;
        }
        else if (num == 2 && rank + 2 < 9 && file + 1 < 9 && !isupper(piece[rank + 2][file + 1]))
        {
            newRank = rank + 2;
            newFile = file + 1;
        }
        else if (num == 2 && rank - 1 > 0 && file - 2 > 0 && !isupper(piece[rank - 1][file - 2]))
        {
            newRank = rank - 1;
            newFile = file - 2;
        }
        else if (num == 2 && rank + 1 < 9 && file - 2 > 0 && !isupper(piece[rank + 1][file - 2]))
        {
            newRank = rank + 1;
            newFile = file - 2;
        }
        else if (num == 2 && rank - 1 > 0 && file + 2 > 0 && !isupper(piece[rank - 1][file + 2]))
        {
            newRank = rank - 1;
            newFile = file + 2;
        }
        else if (num == 2 && rank + 1 < 9 && file + 2 > 0 && !isupper(piece[rank + 1][file + 2]))
        {
            newRank = rank + 1;
            newFile = file + 2;
        }
    }
    else if (c.validMoves[rank][file] == 'K' || c.validMoves[rank][file] == 'k' || c.validMoves[rank][file] == 'Q' || c.validMoves[rank][file] == 'q')
    {
        // Giving the king and queen same moves for now, just when checking for a valid move. This
        // is because if the queen can move even one square in any direction, then there is a valid move.
        
        // The king moves are actually tricky because you'd have to check whether any
        // of the opponent's pieces can capture the king in his new position.*********************************************
        if (num == 1 && rank - 1 > 0 && file - 1 > 0 && !islower(piece[rank - 1][file - 1]))
        {
            newRank = rank - 1;
            newFile = file - 1;
        }
        else if (num == 1 && rank - 1 > 0 && !islower(piece[rank - 1][file]))
        {
            newRank = rank - 1;
            newFile = file;
        }
        else if (num == 1 && rank - 1 > 0 && file + 1 < 9 && !islower(piece[rank - 1][file + 1]))
        {
            newRank = rank - 1;
            newFile = file + 1;
        }
        else if (num == 1 && file - 1 > 0 && !islower(piece[rank][file - 1]))
        {
            newRank = rank;
            newFile = file - 1;
        }
        else if (num == 1 && file + 1 < 9 && !islower(piece[rank][file + 1]))
        {
            newRank = rank;
            newFile = file + 1;
        }
        else if (num == 1 && rank + 1 < 9 && file - 1 > 0 && !islower(piece[rank + 1][file - 1]))
        {
            newRank = rank + 1;
            newFile = file - 1;
        }
        else if (num == 1 && rank + 1 < 9 && !islower(piece[rank + 1][file]))
        {
            newRank = rank + 1;
            newFile = file;
        }
        else if (num == 1 && rank + 1 < 9 && file + 1 < 9 && !islower(piece[rank + 1][file + 1]))
        {
            newRank = rank + 1;
            newFile = file + 1;
        }
        else if (num == 2 && rank - 1 > 0 && file - 1 > 0 && !isupper(piece[rank - 1][file - 1]))
        {
            newRank = rank - 1;
            newFile = file - 1;
        }
        else if (num == 2 && rank - 1 > 0 && !isupper(piece[rank - 1][file]))
        {
            newRank = rank - 1;
            newFile = file;
        }
        else if (num == 2 && rank - 1 > 0 && file + 1 < 9 && !isupper(piece[rank - 1][file + 1]))
        {
            newRank = rank - 1;
            newFile = file + 1;
        }
        else if (num == 2 && file - 1 > 0 && !isupper(piece[rank][file - 1]))
        {
            newRank = rank;
            newFile = file - 1;
        }
        else if (num == 2 && file + 1 < 9 && !isupper(piece[rank][file + 1]))
        {
            newRank = rank;
            newFile = file + 1;
        }
        else if (num == 2 && rank + 1 < 9 && file - 1 > 0 && !isupper(piece[rank + 1][file - 1]))
        {
            newRank = rank + 1;
            newFile = file - 1;
        }
        else if (num == 2 && rank + 1 < 9 && !isupper(piece[rank + 1][file]))
        {
            newRank = rank + 1;
            newFile = file;
        }
        else if (num == 2 && rank + 1 < 9 && file + 1 < 9 && !isupper(piece[rank + 1][file + 1]))
        {
            newRank = rank + 1;
            newFile = file + 1;
        }
    }
    else if (c.validMoves[rank][file] == 'B' || c.validMoves[rank][file] == 'b')
    {
        if (num == 1 && rank - 1 > 0 && file - 1 > 0 && !islower(piece[rank - 1][file - 1]))
        {
            newRank = rank - 1;
            newFile = file - 1;
        }
        else if (num == 1 && rank - 1 > 0 && file + 1 < 9 && !islower(piece[rank - 1][file + 1]))
        {
            newRank = rank - 1;
            newFile = file + 1;
        }
        else if (num == 1 && rank + 1 < 9 && file + 1 < 9 && !islower(piece[rank + 1][file + 1]))
        {
            newRank = rank + 1;
            newFile = file + 1;
        }
        else if (num == 1 && rank + 1 < 9 && file - 1 > 0 && !islower(piece[rank + 1][file - 1]))
        {
            newRank = rank + 1;
            newFile = file - 1;
        }
        else if (num == 2 && rank - 1 > 0 && file - 1 > 0 && !isupper(piece[rank - 1][file - 1]))
        {
            newRank = rank - 1;
            newFile = file - 1;
        }
        else if (num == 2 && rank - 1 > 0 && file + 1 < 9 && !isupper(piece[rank - 1][file + 1]))
        {
            newRank = rank - 1;
            newFile = file + 1;
        }
        else if (num == 2 && rank + 1 < 9 && file - 1 > 0 && !isupper(piece[rank + 1][file - 1]))
        {
            newRank = rank + 1;
            newFile = file - 1;
        }
        else if (num == 2 && rank + 1 < 9 && file + 1 < 9 && !isupper(piece[rank + 1][file + 1]))
        {
            newRank = rank + 1;
            newFile = file + 1;
        }
    }
    else if (c.validMoves[rank][file] == 'R' || c.validMoves[rank][file] == 'r')
    {
        if (num == 1 && rank - 1 > 0 && !islower(piece[rank - 1][file]))
        {
            newRank = rank - 1;
            newFile = file;
        }
        else if (num == 1 && rank + 1 < 9 && !islower(piece[rank + 1][file]))
        {
            newRank = rank + 1;
            newFile = file;
        }
        else if (num == 1 && file + 1 < 9 && !islower(piece[rank][file + 1]))
        {
            newRank = rank;
            newFile = file + 1;
        }
        else if (num == 1 && file - 1 > 0 && !islower(piece[rank][file - 1]))
        {
            newRank = rank;
            newFile = file - 1;
        }
        else if (num == 2 && rank + 1 < 9 && !isupper(piece[rank + 1][file]))
        {
            newRank = rank + 1;
            newFile = file;
        }
        else if (num == 2 && rank - 1 > 0 && !isupper(piece[rank - 1][file]))
        {
            newRank = rank - 1;
            newFile = file;
        }
        else if (num == 2 && file + 1 < 9 && !isupper(piece[rank][file + 1]))
        {
            newRank = rank;
            newFile = file + 1;
        }
        else if (num == 2 && file - 1 > 0 && !isupper(piece[rank][file - 1]))
        {
            newRank = rank;
            newFile = file - 1;
        }
    }
    
    // Still need rook to castle.
    
    *(positions + 0) = rank;                                                    // Use pointer notation to fill array with former and new ranks and files.
    *(positions + 1) = file;
    *(positions + 2) = newRank;
    *(positions + 3) = newFile;
    
    return positions;
}