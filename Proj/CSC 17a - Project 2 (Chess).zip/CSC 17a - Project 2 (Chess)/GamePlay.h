
#ifndef GAMEPLAY_H
#define	GAMEPLAY_H

#include "compMoves.h"

class GamePlay 
{
    public:
        GamePlay();
        virtual ~GamePlay();
        // Passing array of structures through validatePos function.
        bool validatePos(char **, char [], int);                              // (Must pass 2D array to function.) Function determines if the player actually has a piece in a position.
        bool validateMove(char **, char [], char [], int);                              // Function determines whether or not the player chose a valid move.
        int* getCompMove(char **, CompMoves&, int, int);                                // Function determines possible moves for each piece, assigns numbers to the moves, and rand selects move for comp.
        bool findValidMoves(char **, CompMoves&, int, int, int);                        // Function accepts a structure as an argument. The structure is passed by reference. It finds valid moves for comp.
        int *moveCompPiece(char **, CompMoves&, int, int, int);                         // Function actually moves piece on board by displaying the 2D chessPieces array.
    private:
};

#endif	/* GAMEPLAY_H */

