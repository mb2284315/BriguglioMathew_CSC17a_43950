
#include "BoardGame.h"
#include "GameSetUp.h"
#include "GameWriter.h"

BoardGame::BoardGame() 
{

    this->setup = new GameSetUp();
    this->play = new GamePlay();
    this->setup->getPlayerName();  
    this->setup->getPieceColor();
    this->chessPieces = resetBoard(setup->getColor());
    this->currentAN = new char[3];
    this->nextAN = new char[3]; 
    this->writer = new GameWriter(setup->getName());
    

   


}

GameWriter* BoardGame::getGameWriter()
{
    return this->writer;
    
}


BoardGame::~BoardGame() 
{
    delete currentAN;
    delete nextAN; 
    
    for (int i = 0; i < 10; ++i) 
    {
       delete [] chessPieces[i]; 
    }
    
    delete [] chessPieces; 
 
    delete writer;
    
    delete setup;
    delete play;
    
}

char* BoardGame::getCurrentAN()
{
    return this->currentAN;
}

char* BoardGame::getNextAN()
{
    return this->nextAN;
}

void BoardGame::setCurrentAN(char* )
{
    this->currentAN = currentAN;
}

void BoardGame::setNextAN(char*)
{
    this->nextAN = nextAN;
}


// Implement function to put pieces back to original starting positions for a new game.
// Important note: The positions/subscripts of the 2D array are represented with int data types.
// However, the elements of the array are char data types. So when displaying an element or
// comparing an element the int values of the row and column of the array are to be used.


// Implement function to save the position of pieces or to save player's score.
char** BoardGame::resetBoard(int pieceColor)
{
        int ascii = 97, num = 0;                                                    // ascii is for letters a-h. num is for digits 1-8.
        
        // Dynamically allocate memory to 2D array.
        char** chessBoard = new char*[10];                                          // Two dimensional array storing position of chess pieces.
        
        for (int i = 0; i < 10; i++)
            chessBoard[i] = new char[10];
        
        // First for loop assigns 1-8 to column 1 and a-h to row 10.
        // a-h is 97-104 in ASCII code. 1-8 is 49-56 in ASCII code.
        for (int count = 0; count < 10; count++)                                // count is the row number.
        {
            for (int index = 0; index < 10; index++)                            // index is the column number.
            {
                if (count == 9 && index > 0 && index < 9)                       // Row 10 and columns 1 through 8. Prints a-h.
                {
                    chessBoard[count][index] = ascii;
                    ascii++;
                }
                else if (index == 0 && count > 0 && count < 9)                  // Column 1 and rows 1 through 8.
                {
                    chessBoard[count][index] = 56 - num;                        // 56 is the ascii code for 8. 
                    num++;                                                      // Taking 8 - num starts with 8 - 0 = 8, then 8 - 1 = 7, etc. The numbers are decreasing from 8 to 1.
                }
                else
                    chessBoard[count][index] = 32;                              // Assign a space to empty spaces. No pieces yet.
            }   
        }
        // Second for loop assigns 1-8 to column 10, a-h to row 1, and a space to all other elements.
        ascii = 97;
        num = 0;
        for (int count = 0; count < 10; count++)                                // count is the row number.
        {
            for (int index = 0; index < 10; index++)                            // index is the column number.
            {
                if (count == 0 && index > 0 && index < 9)                       // Row 1 and columns 1 through 8. Prints a-h.
                {
                    chessBoard[count][index] = ascii;
                    ascii++;
                }
                else if (index == 9 && count > 0 && count < 9)                  // Column 10 and rows 1 through 8
                {
                    chessBoard[count][index] = 56 - num;
                    num++;
                }
            }   
        }
        
        // Assign the corners * because they're empty.
        chessBoard[0][0] = '*';
        chessBoard[0][9] = '*';
        chessBoard[9][0] = '*';
        chessBoard[9][9] = '*';
        
        // I want the color the player chooses to be at the bottom of the board.
        // If player chooses 2 in newGame function, they chose white, and white pieces (lowercase letters) are at bottom of board.
        if (pieceColor == 2)
        {
            // Assign rows 2 and 3 the appropriate chess pieces. Rows 2 and 3 will be uppercase (black pieces).
            chessBoard[1][1] = chessBoard[1][8] = 'R';
            chessBoard[1][2] = chessBoard[1][7] = 'N';
            chessBoard[1][3] = chessBoard[1][6] = 'B';
            chessBoard[1][4] = 'Q';
            chessBoard[1][5] = 'K';
            for (int count = 1; count < 9; count++)
                chessBoard[2][count] = 'P';
        
            // Assign rows 8 and 9 the appropriate chess pieces. Rows 8 and 9 will be lowercase (white pieces).
            chessBoard[8][1] = chessBoard[8][8] = 'r';
            chessBoard[8][2] = chessBoard[8][7] = 'n';
            chessBoard[8][3] = chessBoard[8][6] = 'b';
            chessBoard[8][4] = 'q';
            chessBoard[8][5] = 'k';
            for (int count = 1; count < 9; count++)
                chessBoard[7][count] = 'a';
            // To understand why pieces are placed in certain rows just look at a chess board.
        }
        // If player chooses 1 in newGame function, they chose black, and black pieces (uppercase letters) are at bottom of board.
        else if (pieceColor == 1)
        {
            // Assign rows 2 and 3 the appropriate chess pieces. Rows 2 and 3 will be uppercase (black pieces).
            chessBoard[1][1] = chessBoard[1][8] = 'r';
            chessBoard[1][2] = chessBoard[1][7] = 'n';
            chessBoard[1][3] = chessBoard[1][6] = 'b';
            chessBoard[1][4] = 'q';
            chessBoard[1][5] = 'k';
            for (int count = 1; count < 9; count++)
                chessBoard[2][count] = 'a';
        
            // Assign rows 8 and 9 the appropriate chess pieces. Rows 8 and 9 will be lowercase (white pieces).
            chessBoard[8][1] = chessBoard[8][8] = 'R';
            chessBoard[8][2] = chessBoard[8][7] = 'N';
            chessBoard[8][3] = chessBoard[8][6] = 'B';
            chessBoard[8][4] = 'Q';
            chessBoard[8][5] = 'K';
            for (int count = 1; count < 9; count++)
                chessBoard[7][count] = 'P';
            // To understand why pieces are placed in certain rows just look at a chess board.
        }
        
        // Display chess board with lines/squares.
        cout << "\n\n\n";
        
        /*
        for (int count = 0; count < 10; count++)                                // Outer for loop displays 1-8 (rows/ranks).
        {
            for (int index = 0; index < 10; index++)                            // Inner for loop displays a-h (columns/files).
            {
                cout << chessBoard[count][index];
                if ((count == 0 || count == 9) && index < 9)
                    cout << "       ";
                if (count > 0 && count < 9 && index < 9)
                    cout << "   |   ";
            }
            if (count > 0 && count < 9)                                         // Inserting extra | to make vertical lines. For rows 1-8 only.
            {
                cout << endl;
                cout << "    |       |       |       |       |       |       |       |       |      ";
            }
            cout << "\n";
            if (count < 9)
                cout << "  _____________________________________________________________________";
            cout << "\n";
        }
        */
        return chessBoard;
}

// Implement function to give game description and rules.
void BoardGame::describeGame()
{
    char ch;
    
    cout << "GAME DESCRIPTION:\n\n";
    cout << "Chess is a strategy-based board game played on a checkered game board. The board is an eight by eight grid,\n"
            "thus it contains 64 squares. Chess is a two player game, and each player begins with 16 pieces: two rooks,\n"
            "two knights, two bishops, one queen, one king, and eight pawns. Each game piece moves in a unique way. If player\n"
            "one moves one of their game pieces and it happens to land on a square occupied by their opponent's game piece,\n"
            "then player one captures player two's game piece and that captured piece is permanently removed from the board.\n"
            "(Player one's game piece now occupies the square and remains on the board.) The only piece that cannot be captured\n"
            "is the king. The objective of the game is to checkmate the opponent's king, meaning that any move the opponent's\n" 
            "king makes, it would be threatened by inevitable capture. If the opponent's king is still able to move to a square\n"
            "where it cannot be captured, then the game continues! Players also earn points by capturing the opponent's game pieces.\n\n";
    // Should I keep score throughout the game, and use the points?
    cout << "Do you already know how the pieces move? If you're a pro, then enter Y. If you need some review, then enter N.";
    cin >> ch;
    
    if (islower(ch))
        ch = toupper(ch);
    if (ch == 'N')
    {
        cout << "\nMOVING THE PIECES:\n\n";
        cout << "Rook: The rook can move any number of squares horizontally or vertically, but it cannot leap over any other pieces.\n"
                "Knight: The knight can move two squares horizontally and then one square vertically OR two squares vertically and then\n"
                "        one square horizontally. Unlike the other pieces, the knight can leap over any other piece and land on its destination\n"
                "        square. The movement of the knight is often referred to as an \"L-shape\"\n"
                "Bishop: The bishop can move any number of squares diagonally, but it cannot leap over any other pieces.\n"
                "Queen: The queen can move any number of squares horizontally, vertically, or diagonally, but it cannot leap over any other pieces.\n"
                "King: The king can move one square horizontally, vertically, or diagonally.\n"
                "Pawn: The pawn can move forward one square or, if it is the pawn's first move, it can move forward two squares. The pawn can also\n"
                "      move diagonally forward one square only when capturing another piece. Lastly, if a pawn reaches the final row of the board\n"
                "      on the opponent's side, then the pawn is promoted to the player's choice of either a rook, knight, bishop, or queen.\n\n";
        cout << "SPECIAL MOVES:\n\n"
                "* Castling: If one of the rooks and the king have not yet moved from their original positions, then they may castle. The king moves\n"
                "            two squares toward the rook the player chooses, and the rook moves to the adjacent square on the other side of the king.\n"
                "* En Passant: If player 2 moves their pawn forward two spaces on the pawn's first move and one of player 1's pawns happens to be to the\n"
                "              left or right (on an adjacent square) then player 1 may capture player 2's pawn \"en passant\" (in passing) by moving to\n"
                "             the square immediately behind player 2's pawn.\n"
                "* Pawn Promotion: If a pawn makes it to the eighth row of the chessboard - on the opponent's side - they may promote their pawn. That is,\n"
                "                  the player will be given the choice of replacing their pawn with either a knight, bishop, rook, or queen.\n\n";
    }
    else
        cout << "Great! You're a pro!\n\n";
    
   setup->pauseScreen();                                                             // pauseScreen function.
    
    cout << "NOTATION KEY FOR THE GAME PIECES:\n\n"
            "Rook:   R or r\n"
            "Knight: N or n\n"
            "Bishop: B or b\n"
            "Queen:  Q or q\n"
            "King:   K or k\n"
            "Pawn:   P or a\n\n"
            "Black Pieces: uppercase letters\n"
            "White Pieces: lowercase letters\n\n";
    
   setup->pauseScreen();
    
    // Display the point system for when pieces are captured.
    cout << "ASSIGNMENT OF POINT VALUES:\n\n"
            "Pawn: 1\n"
            "Knight: 3\n"
            "Bishop: 3\n"
            "Rook: 5\n"
            "Queen: 9\n\n";
    
    cout << "A FEW EXTRA RULES:\n\n";
    cout << "* White always has the first move.\n"
            "* There are no restrictions on pawn promotions; the player may choose whichever piece they prefer each time.\n"
            "* Players may not skip turns.\n"
            "* To capture an opponent's piece, you move your own piece to an appropriate square containing one of the opponent's pieces.\n"
            "  You then permanently remove their piece from the game board, and your piece remains on the square.\n"
            "* The game ends when either a player resigns, there is a draw, or there is a checkmate.\n"
            "  - Draw: It is a draw when neither player can win the game.\n"
            "  - Resignation: A player may resign from (or leave/quit) the game if they believe they will lose.\n"
            "  - Checkmate: A checkmate occurs when one player's king cannot move to a new square without being threatened by inevitable capture.\n\n";
    
   setup->pauseScreen();
    
}


char** BoardGame::getCheesePieces()
{
    return this->chessPieces;
}

void BoardGame::setCheesePieces(char** chessPieces)
{
    this->chessPieces = chessPieces;
}

CompMoves& BoardGame::getCompMoves()
{
    return this->computer;
}

void BoardGame::setCompMoves(CompMoves computer)
{
    this->computer = computer;
}


/*
void BoardGame::newGame()
{
    char ch;                                                                    // char data type for user input.
                                                      // chessPieces 2D array stores the pieces and their positions on the chess board. (e.g. R is on )
    bool validPos;                                                              // Used to validate the position of a chess piece.
    bool validMove;                                                             // Used to validate the move a player chooses.
    
    int newRow, newCol;                                                         // newRow and newCol are the row and column the player moves their piece to.
    int preRow, preCol;                                                         // preRow and PreCol are the row and column where the player's piece was before moving it.
    int nthMove = 1;                                                            // The current move of the game.
    
    const int COMPSIZE = 4;
    int rowsCols[COMPSIZE];
    int *rowsColsPtr;
    rowsColsPtr = rowsCols;
    
    
    cout << "Would you like to save? Enter Y/N: ";
    cin >> ch;
    if (ch == 'Y' || ch == 'y')
        writer->saveGame(setup.getName(), setup.getColor(), nthMove);                                        // Call function to save player's name and piece color.
    else
        cout << "Game will not be saved.\n\n";
    
    setup.showInstruct(setup.getColor());                                                          // Display instructions for how to move pieces using keyboard.
    
    cout << "Press enter to continue.";
    cin.get();
    cout << endl << endl;
    
    // Display that it is the first move, and display whose turn it is.
    if (setup.getColor() == 1)
        cout << "Move: " << nthMove << "\t\tCurrent Move: Computer";
    else if (setup.getColor() == 2)
        cout << "Move: " << nthMove << "\t\tCurrent Move: " << setup.getName();
    // Return the two dimensional array so I can use it in this function.
    chessPieces = resetBoard(setup.getColor());                                              // resetBoard function call resets the chess board.
    
    // do while loop so players can continue to move pieces until player wants
    // to quit game or someone loses.
    do
    {
        // If black then use this code every even number. If white then use it every odd number.
        if ((setup.getColor() == 1 && nthMove % 2 == 0) || (setup.getColor() == 2 && nthMove % 2 == 1))
        {
            
        do
        {
            do
            {        
                cout << "Current Position: ";
                cin >> currentAN[0] >> currentAN[1] >> currentAN[2];
                validPos = play.validatePos(chessPieces, currentAN, setup.getColor());    // Call validPos function to determine if the player entered a valid chess piece and a valid position for it.
                if (validPos == false && currentAN[0] != 'e')
                    cout << "Invalid Position!\n";
                else if (currentAN[0] == 'e')
                    return;
            } while (validPos == false);
            
            do
            {
                cout << "Move To: ";
                cin >> nextAN[0] >> nextAN[1] >> nextAN[2];
                if (nextAN[0] != 'u' && nextAN[0] != 'e')
                {
                    validMove = play.validateMove(chessPieces, currentAN, nextAN, setup.getColor());
                    if (validMove == false)
                        cout << "Invalid Move!\n";
                }
                else if (nextAN[0] == 'u')                                      // If player enters a piece that cannot move anywhere, they can enter uuu to enter a new current position.
                {
                    do
                    {        
                        cout << "Current Position: ";
                        cin >> currentAN[0] >> currentAN[1] >> currentAN[2];
                        validPos = play.validatePos(chessPieces,currentAN, setup.getColor()); // Call validPos function to validate current position.
                        if (validPos == false && currentAN[0] != 'e')
                            cout << "Invalid Position!\n";
                        else if (currentAN[0] == 'e')
                            return;
                    } while (validPos == false);
                        
                    cout << "Move To: ";                                        // If they undo current position and still need to enter where to move piece.
                    cin >> nextAN[0] >> nextAN[1] >> nextAN[2];
                    validMove = play.validateMove(chessPieces, currentAN, nextAN, setup.getColor());
                    if (validMove == false && nextAN[0] != 'e')
                        cout << "Invalid Move!\n";
                    else if (nextAN[0] == 'e')
                        return;
                }
                else if (nextAN[0] == 'e')
                    return;
            
            } while (validMove == false);
            
            // Ask user if they agree with the information they entered.
            cout << endl;
            cout << "(You can enter S to save game.)\n";
            cout << "You entered: " << currentAN[0] << currentAN[1] << currentAN[2] <<
                    " to " << nextAN[0] << nextAN[1] << nextAN[2] << "\n";
            cout << "Is this correct? Enter Y/N: ";
            cin >> ch;
            if (ch == 'S' || ch == 's')                                         // Allow player to save game here.
                writer->saveGame(setup.getName(), setup.getColor(), nthMove);
            cout << endl;
        } while (ch == 'N' || ch == 'n' || ch == 'S' || ch == 's');             // do while asking the user if they want to finalize the move.
        
        if (nextAN[0] != 'c' && nextAN[0] != 'p')                               // If not a special move, move piece to new position with legal rules.
        {
            if ((nextAN[0] == 'P' || nextAN[0] == 'a') && nextAN[2] == '8')     // Code for pawn promotion. Pawn can be promoted to a queen, rook, knight, or bishop.
            {
                if (setup.getColor() == 1)                                                   // Just have player enter a new character for the piece if a pawn makes it to row 8.
                {
                    do
                    {
                        cout << "Pawn Promotion! Select a piece to replace your pawn: N, B, R, or Q. ";
                        cin >> nextAN[0];
                    } while (nextAN[0] != 'N' && nextAN[0] != 'B' && nextAN[0] != 'R' && nextAN[0] != 'Q');
                }
                else if (setup.getColor() == 2)
                {
                    do
                    {
                        cout << "Pawn Promotion! Select a piece to replace your pawn: n, b, r, or q. ";
                        cin >> nextAN[0];
                    } while (nextAN[0] != 'n' && nextAN[0] != 'b' && nextAN[0] != 'r' && nextAN[0] != 'q');
                }
            }
            
            newRow = 57 - static_cast<int>(nextAN[2]);                          // Convert nextAN[2], the row, to the proper row number 1-8.
            newCol = static_cast<int>(nextAN[1]) - 96;                          // Convert nextAN[1], the column, to the proper column number 1-8.
        
            preRow = 57 - static_cast<int>(currentAN[2]);                       // Convert initial piece position to proper row and column numbers 1-8.
            preCol = static_cast<int>(currentAN[1]) - 96;
        
            // Update 2D array.
            chessPieces[newRow][newCol] = nextAN[0];                            // **Very important lines of code - after validating player's move, assign the new position the piece being moved.
            chessPieces[preRow][preCol] = 32;                                   // **And replace the position where the piece was before with a space.
        }
        else if (nextAN[0] == 'c' || nextAN[0] == 'p')                          // If it is a special move: castle or en passant.
        {
            if (nextAN[0] == 'c' && currentAN[1] == 'a')                        // If castling with rook in column a.
            {
                if (setup.getColor() == 1)                                                   // If black pieces.
                {
                    chessPieces[8][3] = 'K';                                    // King moves two spaces closer to rook in column a.
                    chessPieces[8][4] = 'R';                                    // Rook moves one square to right of king.
                }
                else if (setup.getColor() == 2)                                              // If white pieces.
                {
                    chessPieces[8][3] = 'k';                                    // King moves two spaces closer to rook in column a.
                    chessPieces[8][4] = 'r';                                    // Rook moves one square to right of king.
                }
                
                chessPieces[8][1] = 32;                                         // Replace king and rook original positions with a space.
                chessPieces[8][5] = 32;
            }
            else if (nextAN[0] == 'c' && currentAN[1] == 'h')                   // If castling with rook in column h.
            {
                if (setup.getColor() == 1)                                                   // If black pieces.
                {
                    chessPieces[8][7] = 'K';                                    // King moves two spaces closer to rook in column h.
                    chessPieces[8][6] = 'R';                                    // Rook moves one square to left of king.
                }
                else if (setup.getColor() == 2)                                              // If white pieces.
                {
                    chessPieces[8][7] = 'k';                                    // King moves two spaces closer to rook in column h.
                    chessPieces[8][6] = 'r';                                    // Rook moves one square to left of king.
                }
                
                chessPieces[8][8] = 32;                                         // Replace king and rook original positions with a space.
                chessPieces[8][5] = 32;
            }
            else if (nextAN[2] == 'l')                                          // Now code for en passant.
            {
                if (currentAN[1] == 'b')                                        // If player's pawn is in column b and en passant to the left.
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][1] = 'P';                                // Player's pawn moves to this position and it uppercase p because num = 1 (black pieces).
                    else if (setup.getColor() == 2)
                        chessPieces[3][1] = 'a';                                // Player has white pieces so lowercase a.
                    chessPieces [4][2] = 32;                                    // Player's pawn previous position.
                    computer.compPieces[4][1] = '0';                            // Opponent's pawn position - update compPieces array.
                    chessPieces[4][1] = 32;                                     // Opponent's pawn position - update chessboard.
                }
                else if (currentAN[1] == 'c')
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][2] = 'P';
                    else if (setup.getColor() == 2)
                        chessPieces[3][2] = 'a';
                    chessPieces [4][3] = 32;
                    computer.compPieces[4][2] = '0';
                    chessPieces[4][2] = 32;
                }
                else if (currentAN[1] == 'd')
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][3] = 'P';
                    else if (setup.getColor() == 2)
                            chessPieces[3][3] = 'a';
                    chessPieces [4][4] = 32;
                    computer.compPieces[4][3] = '0';
                    chessPieces[4][3] = 32;
                }
                else if (currentAN[1] == 'e')
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][4] = 'P';
                    else if (setup.getColor() == 2)
                        chessPieces[3][4] = 'a';
                    chessPieces [4][5] = 32;
                    computer.compPieces[4][4] = '0';
                    chessPieces[4][4] = 32;
                }
                else if (currentAN[1] == 'f')
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][5] = 'P';
                    else if (setup.getColor() == 2)
                        chessPieces[3][5] = 'a';
                    chessPieces [4][6] = 32;
                    computer.compPieces[4][5] = '0';
                    chessPieces[4][5] = 32;
                }
                else if (currentAN[1] == 'g')
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][6] = 'P';
                    else if (setup.getColor() == 2)
                        chessPieces[3][6] = 'a';
                    chessPieces [4][7] = 32;
                    computer.compPieces[4][6] = '0';
                    chessPieces[4][6] = 32;
                }
                else if (currentAN[1] == 'h')
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][7] = 'P';
                    else if (setup.getColor() == 2)
                        chessPieces[3][7] = 'a';
                    chessPieces [4][8] = 32;
                    computer.compPieces[4][7] = '0';
                    chessPieces[4][7] = 32;
                }
            }
            else if (nextAN[2] == 'r')
            {
                if (currentAN[1] == 'a')                                        // If player's pawn is in column a.
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][2] = 'P';
                    else if (setup.getColor() == 2)
                        chessPieces[3][2] = 'a';
                    chessPieces[4][1] = 32;
                    computer.compPieces[4][2] = '0';
                    chessPieces[4][2] = 32;
                }
                else if (currentAN[1] == 'b')
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][3] = 'P';
                    else if (setup.getColor() == 2)
                        chessPieces[3][3] = 'a';
                    chessPieces[4][2] = 32;
                    computer.compPieces[4][3] = '0';
                    chessPieces[4][3] = 32;
                }
                else if (currentAN[1] == 'c')
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][4] = 'P';
                    else if (setup.getColor() == 2)
                        chessPieces[3][4] = 'a';
                    chessPieces[4][3] = 32;
                    computer.compPieces[4][4] = '0';
                    chessPieces[4][4] = 32;
                }
                else if (currentAN[1] == 'd')
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][5] = 'P';
                    else if (setup.getColor() == 2)
                        chessPieces[3][5] = 'a';
                    chessPieces[4][4] = 32;
                    computer.compPieces[4][5] = '0';
                    chessPieces[4][5] = 32;
                }
                else if (currentAN[1] == 'e')
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][6] = 'P';
                    else if (setup.getColor() == 2)
                        chessPieces[3][6] = 'a';
                    chessPieces[4][5] = 32;
                    computer.compPieces[4][6] = '0';
                    chessPieces[4][6] = 32;
                }
                else if (currentAN[1] == 'f')
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][7] = 'P';
                    else if (setup.getColor() == 2)
                        chessPieces[3][7] = 'a';
                    chessPieces[4][6] = 32;
                    computer.compPieces[4][7] = '0';
                    chessPieces[4][7] = 32;
                }
                else if (currentAN[1] == 'g')
                {
                    if (setup.getColor() == 1)
                        chessPieces[3][8] = 'P';
                    else if (setup.getColor() == 2)
                        chessPieces[3][8] = 'a';
                    chessPieces[4][7] = 32;
                    computer.compPieces[4][8] = '0';
                    chessPieces[4][8] = 32;
                }
            }
        }
        // This large block of code is for the human player.
        }
        else if ((setup.getColor() == 1 && nthMove % 2 == 1) || (setup.getColor() == 2 && nthMove % 2 == 0))
        {            
            // Fill compPiece array on computer's first move.
            if ((setup.getColor() == 1 && nthMove == 1) || (setup.getColor() == 2 && nthMove == 2))
            {
                for (int row = 1; row < 3; row++)
                {
                    for (int col = 1; col < 9; col++)
                    {
                        computer.compPieces[row][col] = chessPieces[row][col];  // Store the computer's pieces and their positions (based on the positions in the 2D array for chessboard) 
                    }
                }
        
                for (int row = 3; row < 9; row++)
                {
                    for (int col = 1; col < 9; col++)
                    {
                        computer.compPieces[row][col] = '0';                    // Fill remaining array elements with zeros to represent a square without one of the computer's pieces.
                    }
                }
            }
            
            // Must update compPieces array right before computer's next move so
            // comp knows where all its pieces are located.
            
            // If the player captures one of the computer's pieces, update the compPiece array
            // so the computer knows which pieces it still has on the chessboard.
            if (nthMove > 3)
            {
                if (computer.compPieces[newRow][newCol] != '0')                 // If the position newRow newCol in compPieces array doesn't hold a 0, then it must mean one of the comp pieces
                    computer.compPieces[newRow][newCol] = '0';                  // was there, and the player just moved their piece there to capture it. So replace this position with a 0.
            }
            // Must update compPieces array right before computer's next move so
            // comp knows where all its pieces are located.
            
            rowsColsPtr = play.getCompMove(chessPieces, computer, setup.getColor(), nthMove);     // Call function to determine valid moves the computer can make and to select a move.
            
            preRow = rowsColsPtr[0];
            preCol = rowsColsPtr[1];
            newRow = rowsColsPtr[2];
            newCol = rowsColsPtr[3];
            
            // Update compPieces array after computer moves a piece. No piece gets
            // a zero, the newly filled square gets added to compPieces array.
            computer.compPieces[newRow][newCol] = chessPieces[preRow][preCol];
            computer.compPieces[preRow][preCol] = '0';
            
            // Print out compPieces array so I know the pieces are being updated.
            cout << endl << endl;
            for (int row = 1; row < 9; row++)
            {
                for (int col = 1; col < 9; col++)
                {
                    cout << computer.compPieces[row][col] << " ";
                }
                cout << endl;
            }
            cout << endl << endl;
            
            // Update chessboard so it can be displayed.
            chessPieces[newRow][newCol] = chessPieces[preRow][preCol];
            chessPieces[preRow][preCol] = 32;
        }
        
        nthMove++;                                                              // Increment nthMove variable to keep track of whose turn it is.
        
        // Display the total number of moves taken so far in the game.
        cout << "Move: " << nthMove << "\t";
        
        // Display whose turn it is.
        
        // If the player chose black pieces and it is the player's turn.
        if (setup.getColor() == 1 && nthMove % 2 == 0)
            cout << "\tCurrent Move: " << setup.getName() << endl;
        // If the player chose white pieces and it is the players turn.
        else if (setup.getColor() == 2 && nthMove % 2 == 1)
            cout << "\tCurrent Move: " << setup.getName() << endl;
        
        // If the player chose black pieces and it is the computer's turn.
        if (setup.getColor() == 1 && nthMove % 2 == 1)
            cout << "\tCurrent Move: Computer\n";
        // If the player chose white pieces and it is the computer's turn.
        else if (setup.getColor() == 2 && nthMove % 2 == 0)
            cout << "\tCurrent Move: Computer\n";
        
        // Display updated chess board.
        cout << "\n";
        for (int count = 0; count < 10; count++)                                // Outer for loop displays 1-8 (rows/ranks).
        {
            for (int index = 0; index < 10; index++)                            // Inner for loop displays a-h (columns/files).
            {
                cout << chessPieces[count][index];
                if ((count == 0 || count == 9) && index < 9)
                    cout << "       ";
                if (count > 0 && count < 9 && index < 9)
                    cout << "   |   ";
            }
            if (count > 0 && count < 9)                                         // Inserting extra | to make vertical lines. For rows 1-8 only.
            {
                cout << endl;
                cout << "    |       |       |       |       |       |       |       |       |      ";
            }
            cout << "\n";
            if (count < 9)
                cout << "  _____________________________________________________________________";
            cout << "\n";
        }
        ch = 'Y';
    } while (ch != 'N' && ch != 'n');                                           // do while loop to determine when game ends. Idk how I will signify the game ending just yet. Maybe, when
    
    // Save game only at end of game play (or during game play).
    //saveGame();
    
    delete writer;
}
*/



GameSetUp* BoardGame::getGameSetUp()
{
    return this->setup;
}

GamePlay* BoardGame::getGamePlay()
{
    return this->play;
}



   