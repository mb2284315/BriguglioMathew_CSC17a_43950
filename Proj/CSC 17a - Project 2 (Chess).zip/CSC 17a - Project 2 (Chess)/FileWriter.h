
#ifndef FILEWRITER_H
#define	FILEWRITER_H

#include <fstream>
using namespace std;

class FileWriter 
{
    public:
        FileWriter(string);
        virtual ~FileWriter();
    protected:
        fstream file;
        string name;
};

#endif	/* FILEWRITER_H */

