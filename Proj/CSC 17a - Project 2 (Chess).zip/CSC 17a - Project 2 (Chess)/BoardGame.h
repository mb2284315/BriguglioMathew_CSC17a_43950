
#ifndef BOARDGAME_H
#define	BOARDGAME_H

using namespace std;
#include <iostream>
#include "GameSetUp.h"
#include "compMoves.h"
#include "GamePlay.h"
#include "GameWriter.h"

class BoardGame 
{
    public:
        BoardGame();
        virtual ~BoardGame();
        char** resetBoard(int);                                                       
        void describeGame();
        GameWriter* getGameWriter();
        GameSetUp* getGameSetUp();
        GamePlay* getGamePlay();
        char** getCheesePieces();
        void setCheesePieces(char**);
        char* getCurrentAN();
        char* getNextAN();
        void setCurrentAN(char*);
        void setNextAN(char*);
        CompMoves& getCompMoves();
        void setCompMoves(CompMoves);
        
    private:
        char **chessPieces;  
        char* currentAN;
        char* nextAN; 
        GameSetUp* setup;
        CompMoves computer; 
        GamePlay* play;
        GameWriter* writer;
};

#endif	/* BOARDGAME_H */

