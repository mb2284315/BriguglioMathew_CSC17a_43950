
#include "GameSetUp.h"
#include <iostream>
using namespace std;


GameSetUp::~GameSetUp() 
{
    
    
}

void GameSetUp::pauseScreen()
{
    cout << "Press enter to continue.";
    cin.ignore();
    cin.get();
    cout << endl << endl;
}

char* GameSetUp::getPlayerName()
{
    char ch;
    do
    {
        //cin.ignore();
        cout << "Enter player initials: ";
        cin >> this->name;
        cout << "\nYou entered: " << this->name << endl;
        cout << "Is this correct? Enter Y/N: ";
        cin >> ch;
    } while (ch == 'N' || ch == 'n');
    cout << endl;
    
    this->name = name;
}

void GameSetUp::getPieceColor()
{     
    cout << "Color of chess pieces:\n\n";
    cout << "1. Black (uppercase letters)\n"
            "2. White (lowercase letters)\n\n";
    do
    {
        cout << "Select a color: ";
        cin >> this->color;
    } while (this->color < 1 || this->color > 2);
    
    cout << endl << endl;

}

void GameSetUp::showInstruct(int num)
{
    // If num = 1, the player chose black pieces.
    if (num == 1)
    {
        cout << "Instructions:\n\n";
        cout << "To move a piece, enter the letter representing the piece, the letter representing the\n"
                "column (file) the piece is in, and the number representing the row (rank) the piece is\n"
                "in. Then enter the same information for the square where you'd like to move it.\n\n"
                "For example: Consider the pawn (represented by the letter P) in column c and row 2.\n"
                "You would press Pc2 then ENTER for its current position. If you wanted to move it one\n"
                "square forward to column c and row 3, then you would press Pc3.\n\n"
                "Also, if you chose Black pieces, then you must enter an uppercase letter to represent the\n"
                "piece you are moving. If you chose white pieces, you must enter a lowercase letter.\n\n";
        pauseScreen();
        cout << "Special Moves:\n\n"
                "Castling: For \"Current Position\" enter position of the rook you want to use when castling and\n"
                "          for \"Move To\" enter ccc\n"
                "En passant: For \"Current Position\" enter position of the pawn you want to use with En passant\n"
                "            move and for \"Move To\" enter ppl (en passant to left) or ppr (en passant to right)\n"
                "Pawn Promotion: Happens automatically once a pawn reaches the eighth row/rank of chessboard\n\n"
                "Hotkeys:\n\n"
                "Exit: eee (You may enter eee to exit when the game asks for \"Current Position\" or \"Move To\")\n"
                "Undo: uuu (After entering the \"Current Position\" you may enter uuu to choose a different piece to move)\n"
                "Save: S (You may save game in beginning of game or when finalizing a move)\n\n";
    }
    // If num = 2, the player chose white pieces.
    else if (num == 2)
    {
        cout << "Instructions:\n\n";
        cout << "To move a piece, enter the letter representing the piece, the letter representing the\n"
                "column (file) the piece is in, and the number representing the row (rank) the piece is\n"
                "in. Then enter the same information for the square where you'd like to move it.\n\n"
                "For example: Consider the pawn (represented by the letter a) in column c and row 2.\n"
                "You would press ac2 then ENTER for its current position. If you wanted to move it one\n"
                "square forward to column c and row 3, then you would press ac3.\n\n"
                "Also, if you chose Black pieces, then you must enter an uppercase letter to represent the\n"
                "piece you are moving. If you chose white pieces, you must enter a lowercase letter.\n\n";
        pauseScreen();
        cout << "Special Moves:\n\n"
                "Castling: For \"Current Position\" enter position of the rook you want to use when castling and\n"
                "          for \"Move To\" enter ccc\n"
                "En passant: For \"Current Position\" enter position of the pawn you want to use with En passant\n"
                "            move and for \"Move To\" enter ppl (en passant to left) or ppr (en passant to right)\n"
                "Pawn Promotion: Happens automatically once a pawn reaches the eighth row/rank of chessboard\n\n"
                "Hotkeys:\n\n"
                "Exit: eee (You may enter eee to exit when the game asks for \"Current Position\" or \"Move To\")\n"
                "Undo: uuu (After entering the \"Current Position\" you may enter uuu to choose a different piece to move)\n"
                "Save: S (You may save game in beginning of game or when finalizing a move)\n\n";
    }
}

string GameSetUp::getName()
{
    return this->name;
}

void GameSetUp::setName(string name)
{
    this->name = name;
}

int GameSetUp::getColor()
{
    return this->color;
}

void GameSetUp::setColor(int color)
{   
    this->color = color;
}