
#ifndef GAMESETUP_H
#define	GAMESETUP_H

using namespace std;
#include <iostream>

class GameSetUp 
{
    public:
        virtual ~GameSetUp();                                                                                               // Function stores player name in character array.
        void getPieceColor();                                                           
        void showInstruct(int);
        string getName();
        void setName(string);
        void pauseScreen();
        char* getPlayerName();
        int getColor();
        void setColor(int);
        
    private:
        string name;
        int color;
};

#endif	/* GAMESETUP_H */

