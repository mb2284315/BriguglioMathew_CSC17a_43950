#include "RetailItem.h"

RetailItem::RetailItem(string d, int u, float p)
{
    description = d; // set description
    unitsOnHand = u; // set units 
    price = p; // set price

}

RetailItem::RetailItem()
{
    description = "NULL"; // set description
    unitsOnHand = 0; // set units 
    price = 0; // set price

}

