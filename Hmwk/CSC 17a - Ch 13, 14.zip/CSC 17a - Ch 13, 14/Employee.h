// Specification file for the Employee class
#include <string>
using namespace std;

#ifndef EMPLOYEE_H
#define	EMPLOYEE_H

class Employee
{
    private:
        string name; // employee name
        int idNumber; // employee id number
        string department; // employee department
        string position; // employee position

    public:
        Employee(string n, int i, string d, string p); // constructor 1
        Employee(string n, int i);// constructor 2
        Employee();// constructor 3
        void setName(string n) // get the name
        {name = n;}
        void setID(int i ) // get the id number
        {idNumber = i;}
        void setDepartment(string d) // get the department 
        {department = d;}
        void setPosition(string p) // get the position
        {position = p;}
        string getName() // return name
        {return name;}
        int getID() const// return id
        {return idNumber;}
        string getDepartment() const // return department
        {return department;}
        string getPosition() const // return position
        {return position;}
};
#endif	/* EMPLOYEE_H */

