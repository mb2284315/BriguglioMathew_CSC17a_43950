

#ifndef FUELGAUGE_H
#define	FUELGAUGE_H

class FuelGauge
{
    private:
        float gallons;
        
    public:
        FuelGauge();
        float getGallons()
        {return gallons;}
        FuelGauge operator++();        
        FuelGauge operator--(); 
};


#endif	/* FUELGAUGE_H */

