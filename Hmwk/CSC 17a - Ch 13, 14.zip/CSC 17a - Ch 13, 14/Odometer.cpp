#include "Odometer.h"
#include "FuelGauge.h"

Odometer Odometer::operator++()
{
    if(mileage != 999999)
    {
        ++mileage;
        
        if(static_cast<int>(mileage) % 24 == 0)
        {
          fuelgauge.operator--();
        }
        return *this;
    }
    else
    {
        mileage = 0;
        ++mileage;
        return *this;
    }
}

Odometer::Odometer()
{
    mileage = 0;
}



