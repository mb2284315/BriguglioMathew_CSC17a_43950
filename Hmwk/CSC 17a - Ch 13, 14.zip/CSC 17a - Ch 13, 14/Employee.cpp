#include <cstdlib>
#include "Employee.h"
#include <iostream>

Employee::Employee(string n, int i, string d, string p) // constructor 1
{
    name = n; // set name by user
    idNumber = i; // set id by user
    department = d; // set department by user
    position = p; // set position by user
}

Employee::Employee(string n, int i)// constructor 2
{ 
    name = n; // set name by user
    idNumber = i; // set id by user
    department = "";// set department
    position = ""; // set position
}

Employee::Employee()// constructor 3
{
    name = ""; // set name
    idNumber = 0;  // set id
    department = ""; // set department
    position = ""; // set position
}
