#include "DayOfYear.h"
#include <iostream>
using namespace std;

void DayOfYear::print() 
{
    months[0] = "January";
    months[1] = "February";
    months[2] = "March";
    months[3] = "April";
    months[4] = "May";
    months[5] = "June";
    months[6] = "July";
    months[7] = "August"; 
    months[8] = "September"; 
    months[9] = "October";
    months[10] = "November";
    months[11] = "December";

    if (months[0] == month)
    {
        if(day > 0 && day <= 31)
        {
           cout << "This is the " << day << " day of the year" << endl; 
        }
        else
        {
            cout << "Not valid" << endl;
            return;
        }
    }
    else if (months[1] == month)
    {
        if(day > 0 && day <= 28)
        {
            day = 31 + day;
            cout << "This is the " << day << " day of the year" << endl; 
        }
        else
        {
            cout << "Not valid" << endl;
            return;
        }
    }
    else if (months[2] == month)
    {
        if(day > 0 && day <= 31)
        {
           day = 59 + day;
           cout << "This is the " << day << " day of the year" << endl; 
        }
        else
        {
            cout << "Not valid" << endl;
            return;
        }
    }
    else if (months[3] == month)
    {
        if(day > 0 && day <= 30)
        {
            day = 90 + day;
            cout << "This is the " << day << " day of the year" << endl; 
        }
        else
        {
            cout << "Not valid" << endl;
            return;
        }
    }

    else if (months[4] == month)
    {
        if(day > 0 && day <= 31)
        {
            day = 120 + day;
            cout << "This is the " << day << " day of the year" << endl; 
        }
        else
        {
            cout << "Not valid" << endl;
            return;
        }
    }
    
    else if (months[5] == month)
    {
        if(day > 0 && day <= 30)
        {
           day = 151 + day;
           cout << "This is the " << day << " day of the year" << endl; 
        }
        else
        {
            cout << "Not valid" << endl;
            return;
        }
    }
    
    else if (months[6] == month)
    {
        if(day > 0 && day <= 31)
        {
           day = 181 + day;  
           cout << "This is the " << day << " day of the year" << endl; 
        }
        else
        {
            cout << "Not valid" << endl;
            return;
        }
    }

    else if (months[7] == month)
    {
        if(day > 0 && day <= 31)
        {
           day = 212 + day;
           cout << "This is the " << day << " day of the year" << endl; 
        }
        else
        {
            cout << "Not valid" << endl;
            return;
        }
    }
    
    else if (months[8] == month)
    {
        if(day > 0 && day <= 30)
        {
            day = 243 + day;  
            cout << "This is the " << day << " day of the year" << endl; 
        }
        else
        {
            cout << "Not valid" << endl;
            return;
        }
    }
    
    else if (months[9] == month)
    {
        if(day > 0 && day <= 31)
        {
            day = 273 + day;  
            cout << "This is the " << day << " day of the year" << endl; 
        }
        else
        {
            cout << "Not valid" << endl;
            return;
        }
    }

    else if (months[10] == month)
    {
        if(day > 0 && day <= 30)
        {
            day = 304 + day;
            cout << "This is the " << day << " day of the year" << endl; 
        }
        else
        {
            cout << "Not valid" << endl;
            return;
        }
    }
    
    else if (months[11] == month)
    {
        if(day > 0 && day <= 31)
        {
            day = 334 + day;  
            cout << "This is the " << day << " day of the year" << endl; 
        }
        else
        {

            cout << "Not valid" << endl;
            return;
        }
    }    
    else
    {
        if (day > 0 && day <= 31)
        {
            cout << months[0] << " " << day << endl;
        }
        else if (day >= 32 && day <= 59)
        {
            day = (day - (365 - 334));
            cout << months[1] << " " << day << endl;
        }
        else if (day >= 60 && day <= 90)
        {
            day = (day - (365 - 306));
            cout << months[2] << " " << day << endl;
        }
        else if (day >= 91 && day <= 120)
        {
            day = (day - (365 - 275));
            cout << months[3] << " " << day << endl;
        }

        else if (day >=121  && day <= 151)
        {
            day = (day - (365 - 245));
            cout << months[4] << " " << day << endl;
        }

        else if (day >= 152 && day <= 181)
        {
            day = (day - (365 - 214));
            cout << months[5] << " " << day << endl;
        }

        else if (day >= 182 && day <= 212)
        {
            day = (day - (365 - 184));
            cout << months[6] << " " << day << endl;
        }

        else if (day >= 213 && day <= 243)
        {
            day = (day - (365 - 153));
            cout << months[7] << " " << day << endl;
        }

        else if (day >= 244 && day <= 273)
        {
            day = (day - (365 - 122));
            cout << months[8] << " " << day << endl;
        }

        else if (day >= 274 && day <= 304)
        {
            day = (day - (365 - 92));
            cout << months[9] << " " << day << endl;
        }

        else if (day >= 305 && day <= 334)
        {
            day = (day - (365 - 61));
            cout << months[10] << " " << day << endl;
        }

        else if (day >= 335 && day <= 365)
        {
            day = (day - (365 - 31));
            cout << months[11] << " " << day << endl;
        }
    }
}

DayOfYear DayOfYear::operator++()
{
    ++day;
    return *this;
}

 DayOfYear DayOfYear::operator--()
{
    --day;
    return *this;
}
 
