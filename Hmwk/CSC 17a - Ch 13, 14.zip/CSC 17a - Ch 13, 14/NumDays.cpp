#include "NumDays.h"


void NumDays::computeHours(float hours)
{
    days = hours / 8;
}

NumDays::NumDays()
{
    hours = 0;
    days = 0;
}

NumDays NumDays::operator + (const NumDays &hours1)
{
    NumDays hours2;
    hours2.hours = hours + hours1.hours;
    hours2.computeHours(hours2.hours);
    return hours2;
}

NumDays NumDays::operator - (const NumDays &hours1)
{
    NumDays hours2;
    hours2.hours = hours - hours1.hours;
    hours2.computeHours(hours2.hours);
    return hours2;  
}

NumDays NumDays::operator++ ()
{
   ++hours;
   return *this;
}

NumDays NumDays::operator-- ()
{
   --hours;
   return *this;  
}

