#include "Personal.h"

Personal::Personal() // default constructor
{
    name =  "NULL"; // set name to null
    address = "NULL"; // set address to null
    age = 0; // set age to 0
    number = "NULL"; // set number to null
}
