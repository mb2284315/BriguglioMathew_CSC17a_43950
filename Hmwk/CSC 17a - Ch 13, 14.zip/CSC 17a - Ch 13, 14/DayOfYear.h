#include <string>
using namespace std;

#ifndef DAYOFYEAR_H
#define	DAYOFYEAR_H

class DayOfYear
{
        private:
                string months[12];
                int day;
                string month;
                
        public: 
                DayOfYear(int d)
                {day = d; month = "NULL";}
                DayOfYear(string m, int d)
                {month = m; day = d;}
                void print();  
                DayOfYear operator++();
                DayOfYear operator--();
};
#endif	/* DAYOFYEAR_H */



