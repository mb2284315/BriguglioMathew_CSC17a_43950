#include <string>
using namespace std;

#ifndef RETAILITEM_H
#define	RETAILITEM_H

class RetailItem
{
    private:
        string description; // description 
        int unitsOnHand; // units in stock
        float price; // price
        
    public: 
        RetailItem(); // constructor 
        RetailItem(string d, int u, float p); // constructor to initialize all variables
        string getDesc() //return description
        {return description;}
        int getUnits() //return number of units in stock
        {return unitsOnHand;}
        float getPrice() // return price
        {return price;} 
        void setDesc(string d) // set desc
        {description = d;}
        void setUnits(int u) // set units
        {unitsOnHand = u;}
        void setPrice(float p) // set price
        {price = p;}
};



#endif	/* RETAILITEM_H */

