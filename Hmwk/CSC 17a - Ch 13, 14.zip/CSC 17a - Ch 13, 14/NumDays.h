#ifndef NUMDAYS_H
#define	NUMDAYS_H

class NumDays
{
     private:
         float hours;
         float days;
         void computeHours(float hours);

     public:
         NumDays();
         NumDays(float hours)
         {this->hours = hours; computeHours(this->hours);}
         float getDays() const
         {return days;}
         float getHours() const
         {return hours;}
         NumDays operator + (const NumDays &);
         NumDays operator - (const NumDays &);
         NumDays operator++ ();
         NumDays operator-- ();  
};

#endif	/* NUMDAYS_H */

