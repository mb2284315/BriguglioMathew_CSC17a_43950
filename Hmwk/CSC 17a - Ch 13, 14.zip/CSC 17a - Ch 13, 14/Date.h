// Specification file for the Date class
#include <string>
using namespace std;

#ifndef DATE_H
#define DATE_H

class Date
{
    private:
        int month; // month
        int day; // day 
        int year; // year
        string getMonth() const; // get month from an int representation
    public:
        void setMonth(int); //set the month and check if it is valid
        void setDay(int); //set the day and check if it is valid
        void setYear(int y) //set the year and check if it is valid
        {
            year = y; // user input becomes the year
        }  
        void date1(); // date display version 1
        void date2(); // date display version 2
        void date3(); // date display version 3
};

#endif	/* DATE_H */

