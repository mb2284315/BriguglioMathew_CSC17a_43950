#include "Car.h"

Car::Car(int ym, string m)
{
    yearModel = ym; // put user input into year
    make = m; // put uuser input for make
    speed = 0; // set speed to zero
}