#include <string>
using namespace std;

#ifndef PERSONAL_H
#define	PERSONAL_H

class Personal
{
    private:
        string name; // persons name
        string address; // persons address
        int age; // persons age
        string number; // persons number
    public:
        Personal(); // constructor 
        void setName(string n) // set name from user
        {name = n;}
        void setAddress(string a) // set address from user
        {address = a;}
        void setAge(int a) // set age from user
        {age = a;}
        void setNumber(string n) // set number from user
        {number = n;}
        string getName() // get name for user
        {return name;}
        string getAddress() // get address for user
        {return address;}
        int getAge() // get age for user
        {return age;}
        string getNumber() // get number for user
        {return number;}  
};


#endif	/* PERSONAL_H */

