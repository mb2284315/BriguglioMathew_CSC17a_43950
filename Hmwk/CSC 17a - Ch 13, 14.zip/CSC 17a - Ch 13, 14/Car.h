// Specification file for the Dar class
#include <string>
using namespace std;

#ifndef CAR_H
#define	CAR_H

class Car
{
    private:
        int yearModel; // year or model of car
        string make; // make of car
        int speed; // speed of car
      
    public:
        Car(int ym, string m); //constructor 
        int getYealModel() const // get year
        {return yearModel;} // return model/year
        string getMake() const // get make
        {return make;} // return make
        int getSpeed() const // get speed
        {return speed;} // return speed
        void accelerate() // get acceleration
        { speed += 5;} // add 5 to speed
        void brake() // get braked speed
        { speed -= 5;} // subtract 5 from speed
};

#endif	/* CAR_H */

