#include <cstdlib>
#include "Date.h"
#include <iostream>

void Date::setMonth(int m)//set the month and check if it is valid
{
    while(m > 12 || m < 1) // if month is not in valid range
    {
        cout << "Please enter a month between 1 and 12: "; // ask user to re-enter
            cin >> m;
    }
    month = m; // month is now the user's input
}

void Date::setDay(int d) //set the day and check if it is valid
{
    while(d > 31 || d < 1)  // if dayis not in valid range
    {
        cout << "Please enter a day between 1 and 31: "; // ask user to re-enter
            cin >> d;
    } 
    day = d; // day is now the user's input
}

void Date::date1() // version one
{
    cout << month << "/" << day << "/" << year << endl; // display version 1
}

void Date::date2() // version 2
{
  cout << getMonth() << " " << day << "," << year << endl; // display version 2
}

void Date::date3() // version 3
{
  cout << day << " " << getMonth() << " " << year << endl; // display version 3
}

string Date::getMonth() const // get the month int and find its string equivalent
{
    switch(month) // egt int of month 
    {
        case 1: // if it is 1
            return "January"; // return equivalent string 
            break;
        case 2: // if it is 2
            return "February"; // return equivalent string 
            break;
        case 3: // if it is 3
            return "March"; // return equivalent string 
            break;
        case 4: // if it is 4
            return "April"; // return equivalent string 
            break;
        case 5: // if it is 5
            return "May"; // return equivalent string 
            break;
        case 6: // if it is 6
            return "June"; // return equivalent string 
            break;
        case 7: // if it is 7
            return "July"; // return equivalent string 
            break;
        case 8: // if it is 8
            return "August"; // return equivalent string 
            break;
        case 9: // if it is 9
            return "September"; // return equivalent string 
            break;
        case 10: // if it is 10
            return "October"; // return equivalent string 
            break;
        case 11: // if it is 11
            return "November"; // return equivalent string 
            break;
        case 12: // if it is 12
            return "December"; // return equivalent string 
            break;
    };
}
