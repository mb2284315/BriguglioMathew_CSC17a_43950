/* 
 * File:   main.cpp
 * Author: Mathew Briguglio
 * Purpose: Switch Menu for C++ Hmwk Problems - Assignment 1
 * Created on February 23, 2015, 11:05 PM
 */

#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <fstream>

using namespace std;

/*
 * 
 */

//Function Prototypes
void problem1();
void problem2();
void problem3();
void problem4();
void problem5();
void problem6();
void problem7();

void celcius(float, float);

int main()
{
    const short PROB1 = 1, PROB2 = 2, PROB3 = 3, PROB4 = 4, PROB5 = 5, PROB6 = 6, PROB7 = 7, QUIT = 8;
    short choice;
    
    do
    {
        cout << "__________________________________________________________________________________________________________________\n";
        cout << "\t\t  Homework Menu\n";
        cout << "\t\t-----------------\n\n"
             << "1. Problem 3.12\n"
             << "2. Problem 3.13\n"
             << "3. Problem 4.10\n"
             << "4. Problem 5.11\n"
             << "5. Problem 6.7\n"
             << "6. Problem 7.6\n"
             << "7. Problem 8.7\n"   
             << "8. Quit.\n\n";
        do
        {
            cout << "Select one of the available options (1 through 8). The program will not continue until a valid option is selected.\n";
            cout << "Enter your choice: ";
            cin >> choice;
            cout << endl;
        } while (choice < 1 || choice > 8);
        
        cout << "__________________________________________________________________________________________________________________\n";
    
        switch (choice)
        {
            case 1:
                cout << "\nThis is Hmwk Problem 3.12.\n\n";
                problem1();
                break;
            
            case 2:
                cout << "\nThis is Hmwk Problem 3.13.\n\n";
                problem2();
                break;
            
            case 3:
                cout << "\nThis is Hmwk Problem 4.10.\n\n";
                problem3();
                break;
                
            case 4:
                cout << "\nThis is Hmwk Problem 5.11.\n\n";
                problem4();
                break;
            
            case 5:
                cout << "\nThis is Hmwk Problem 6.7.\n\n";
                problem5();
                break;
            
            case 6:
                cout << "\nThis is Hmwk Problem 7.6.\n\n";
                problem6();
                break;
                
            case 7:
                cout << "\nThis is Hmwk Problem 8.7.\n\n";
                problem7();
                break;
        
        }
    
    } while (choice != QUIT);

    return 0;
}


void problem1()
{
    //Declare variables.
    string month;
    unsigned short year;
    float totalIncome, productSales, countyTax, stateTax, totalTax;
    
    //Ask user to enter month, year, and total income
    cout << "To calculate monthly sales tax report,\n"
         << "please first enter the month, then the year,\n"
         << "then the total income, separated by spaces.\n\n";
    
    //Collect data.
    cin >> month >> year >> totalIncome;
    
    //Calculate sales without state and county tax: 1*sales + 0.4*sales + 0.2*sales = total
    productSales = totalIncome/1.06;
    
    //Calculate county tax
    countyTax = 0.02 * productSales;
    
    //Calculate state tax
    stateTax = 0.04 * productSales;
    
    //Calculate total tax: (county + state tax)
    totalTax = countyTax + stateTax;
    
    //Display monthly sales tax report.
    cout << endl << "Month: " << month << endl;
    cout << "Year: " << year << endl;
    cout << "--------------------" << endl;
    cout << setprecision(2) << fixed;
    cout << setw(20) << left << "Total Collected:" << left << "$ " << totalIncome << endl;
    cout << setw(20) << left << "Sales:" << left << "$ " << productSales << endl;
    cout << setw(20) << left << "County Sales Tax:" << left << "$ " << countyTax << endl;
    cout << setw(20) << left << "State Sales Tax:" << left << "$ " << stateTax << endl;
    cout << setw(20) << left << "Total Sales Tax:" << left << "$ " << totalTax << endl;
}

void problem2()
{
    float actualValue, assessValue, propTax;
    
    cout << "This program will calculate and display the assessment value and property tax of a piece of property.\n\n\n";
    cout << "Enter the actual value of the property.\n\n$ ";
    cin >> actualValue;
    
    assessValue = 0.6*actualValue;
    
    propTax = 0.0064*assessValue;
    
    cout << setprecision(2) << fixed;
    cout << endl << endl << left << setw(20) << "Assessment Value:" << "$ " << assessValue << endl;
    cout << left << setw(20) << "Property Tax:" << "$ " << propTax << endl;
}

void problem3()
{
    short quantity;
    float totCost;
    
    //Ask user for quantity of units sold.
    cout << "Enter the quantity of units sold, a discount may be given, and the total cost of the purchase will be computed.\n\n";
    cin >> quantity;
    
    //Input Validation
    if (quantity <= 0)
        cout << "\n\n" << quantity << " is an invalid input. The quantity must be greater than zero. Restart the program and enter a quantity greater than zero.\n";
    else
    {
        if (quantity > 0 && quantity < 10)
            totCost = quantity*99;
        else if (quantity >= 10 && quantity <= 19)
            totCost = 0.8*quantity*99;
        else if (quantity >= 20 && quantity <= 49)
            totCost = 0.7*quantity*99;
        else if (quantity >= 50 && quantity <= 99)
            totCost = 0.6*quantity*99;
        else if (quantity >= 100)
            totCost = 0.5*quantity*99;
        
        //Display the total cost of the purchase.
        cout << setprecision(2) << fixed;
        cout << endl << "Total Cost: $ " << totCost << endl;
    }
}

void problem4()
{
    int numDays, population;
    float growthRate;
    
    do {
        cout << "Enter the initial population. It must be greater than or equal to\n"
                "2 organisms.\n";
        cin >> population;
    } while (population < 2);
    
    do {
        cout << "Enter a whole number between 1 and 100 for the percentage growth rate\n"
                "of the organisms.\n";
        cin >> growthRate;
    } while (growthRate <= 0);
    
    do {
        cout << "Enter the number of days the population will multiply. It must be\n"
                "multiplying for 1 or more days.\n";
        cin >> numDays;
    } while (numDays < 1);
    
    growthRate = growthRate/100;
    
    cout << endl << endl;
    
    for (int count = 0; count < numDays; count++) {
        
        population = population + (population)*growthRate;
        
        cout << "Day " << count + 1 << ": " << population << endl;
    }
}

void problem5()
{
    float fahr, celc, result;
    
    cout << "Fahrenheit \t Celsius" << endl;
    cout << "------------------------" << endl << endl;
    
    for (fahr = 0; fahr <= 20; fahr++){
        
        celcius(fahr, celc);
    }
    
    cout << "------------------------" << endl;
}

void celcius(float fahr, float celc){
    
    celc = static_cast<float>(5)/9*(fahr-32);
    
    cout << fahr << " \t\t " << setprecision(2) << fixed << showpoint << celc << endl;
}

void problem6()
{
    // Writing data to a file. Outputting data means we're sending it "out" of the IDE and to the file.
    ofstream outputFile;
    int num1 = 104, num2 = 102, num3 = 109, num4 = 105, num5 = 101, num6 = 103;
    
    outputFile.open("SampleFile.txt");
    
    outputFile << num1 << endl;
    outputFile << num2 << endl;
    outputFile << num3 << endl;
    outputFile << num4 << endl;
    outputFile << num5 << endl;
    outputFile << num6 << endl;
    
    outputFile.close();
    
    // Now the data from the file will be read into an array called fileContents. There are only 6 elements in the file, but the array has space for 500 elements.
    // The array will determine it only needs 6 elements.
    
    ifstream inputFile;                     // Input file stream object.
    string filename;                        // For the file name entered by the user.
    const unsigned short SIZE = 500;        // Size of partially filled array.
    int fileContents[SIZE], count = 0;      // Array that will hold numbers from file. Count is a loop counter variable.
    int total = 0;                          // Accumulator variable. total will sum up all the elements written to the array from the file.
    int highest, lowest;                    // The highest and lowest values in the array or file.
    float average;                          // The average or arithmetic mean of the numbers in the file.
    
    cout << "Enter the filename: ";         // Ask the user for the file name.
    cin >> filename;
    cout << endl;
    
    inputFile.open(filename.c_str());           // After the user enters a file name, this command will open the file.
    
    while (count < SIZE && inputFile >> fileContents[count])        // The while loop will begin with count = 0, and then go to count = 1, up to count = 5. After count = 5, the while loop
        count++;                                                    // will increment count once more, letting count = 6, and this will give the actual size of the array.
    
    inputFile.close();              // Close the file.
    
    cout << "The contents of the file are: ";                            // This for loop only prints the numbers from the array or file.
    for (int index = 0; index < count; index++)
        cout << fileContents[index] << " ";
    cout << endl << endl;
    
    for (int index = 0; index < count; index++)             // This for loop sums up all the elements in the array or file.
        total += fileContents[index];
    
    average = total / count;                    // The average of the numbers in the file is calculated.
    
    highest = fileContents[0];                          // This code will find the highest value in the array of numbers taken from the file.
    for (int index = 1; index < count; index++) {
        if (fileContents[index] > highest)
            highest = fileContents[index];
    }
    
    lowest = fileContents[0];                          // This code will find the lowest value in the array of numbers taken from the file.
    for (int index = 1; index < count; index++) {
        if (fileContents[index] < lowest)
            lowest = fileContents[index];
    }
    
    cout << "Total: " << total << endl;
    cout << "Average: " << average << endl;
    cout << "Highest: " << highest << endl;
    cout << "Lowest: " << lowest << endl << endl;
}

void problem7()
{
    const int NUM_NAMES = 20;
    string names[NUM_NAMES] = {"Collins, Bill", "Smith, Bart", "Allen, Jim", "Griffin, Jim",
                               "Stamey, Marty", "Rose, Geri", "Taylor, Terri", "Johnson, Jill",
                               "Allison, Jeff", "Looney, Joe", "Wolfe, Bill", "James, Jean",
                               "Weaver, Jim", "Pore, Bob", "Rutherford, Greg", "Javens, Renee",
                               "Harrison, Rose", "Setzer, Cathy", "Pike, Gordon","Holland, Beth"};
    string searchName = "Pore, Bob";
    
    // Sorting the array.
    bool swap;
    string temp;
    
    do
    {
        swap = false;
        for (unsigned short count = 0; count < (NUM_NAMES - 1); count++)
        {
            if (names[count] > names[count + 1])
            {
                temp = names[count];
                names[count] = names[count + 1];
                names[count + 1] = temp;
                swap = true;
            }
        }
    } while (swap);
    
    //for (int index = 0; index < NUM_NAMES; index++)       // Don't forget about these lines of code. It prints the array of names alphabetically.
        //cout << names[index] << endl;
    
    // Binary search performed on sorted array.

    unsigned short first = 0,                                 //First array element
                   last = NUM_NAMES - 1,                      //Last array element
                   middle;                                    //Midpoint of search

    short position = -1;                                      //Position of search value (Must be a short, not an unsigned short)
    
    bool found = false;                                       //Flag
    
    while (!found && first <= last)
    {
        middle = (first + last) / 2;                          //Calculate the midpoint
        if (names[middle] == searchName)
        {
            found = true;
            position = middle;
        }
        else if (names[middle] > searchName)             //This means that the value being searched for is in the lower half of the array.
        {
            last = middle - 1;
        }
        else
            first = middle + 1;                              //If the value isn't in the middle or in the lower half, then it must be in the upper half.
                                                             //First is now the first value of the upper half of the array.
    }
    
    
    if (position == -1)                                                                                  //If the number -1 is stored in results, then the searchValue was not found.
        cout << "The name " << searchName << " does not exist in the array.\n";
    else
    {
        cout << "The name " << searchName << " is found at element(s):\n\n";
        cout << position << endl;
    }
    
    
}