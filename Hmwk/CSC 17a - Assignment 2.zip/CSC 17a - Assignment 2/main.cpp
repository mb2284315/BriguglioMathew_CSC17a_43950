 /* 
 * File:   main.cpp
 * Author: Mathew Briguglio
 * Purpose: CSC 17a - Assignment 2 - Mean, Median, Mode, and Five Ch. 9 Problems
 * Created on March 16, 2015, 10:07 PM
 */

#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <ctime>
#include <fstream>

using namespace std;

/*
 * 
 */

// Function Prototypes
void meanMedianMode();
void problem1();
void problem2();
void problem3();
void problem4();
void problem5();

// Functions called by meanMedianMode
float mean(int [], int);
float median(int [], int);
int *mode(int [], int, int, int, int);
void printSetArray(int [], int);
void printFreqArray(int [], unsigned short);

// Functions called by problem1
int *dynAlloc(int);

// Functions called by problem2
void sortScores(int [], int);
float averageScores(int [], int);

// Functions called by problem3
void sortScores(int [], int);
float avgScoresDrop(int [], int);

// Functions called by problem4
void arrSelectSort(int *[], int);
void showArray(const int [], int);
void showArrPtr(int *[], int);

// Functions called by problem5
void arr_SelectSort(int *[], int);
void show_Array(const int [], int);
void show_ArrPtr(int *[], int);

int main()
{
    const short PROB1 = 1,
                PROB2 = 2,
                PROB3 = 3,
                PROB4 = 4,
                PROB5 = 5,
                PROB6 = 6,
                QUIT = 7;
    short choice;
    
    do
    {
        cout << "__________________________________________________________________________________________________________________\n";
        cout << "\t\t  Homework Menu\n";
        cout << "\t\t-----------------\n\n"
             << "1. Mean, Median, Mode\n"
             << "2. Problem 9.1\n"
             << "3. Problem 9.2\n"
             << "4. Problem 9.3\n"
             << "5. Problem 9.6\n"
             << "6. Problem 9.7.\n"
             << "7. Quit.\n\n";
        do {
            cout << "Select one of the available options (1 through 7). The program will not continue until a valid option is selected.\n";
            cout << "Enter your choice: ";
            cin >> choice;
            cout << endl;
        } while (choice < 1 || choice > 7);
        
        cout << "__________________________________________________________________________________________________________________\n";
    
        switch (choice) {
            case 1:
                cout << "\nThis program calculates the mean, median, and mode for a repeating set of numbers 0-9.\n\n";
                meanMedianMode();
                break;
            
            case 2:
                // Array Allocator
                cout << "\nThis is Hmwk Problem 9.1.\n\n";
                problem1();
                break;
            
            case 3:
                // Test Scores #1
                cout << "\nThis is Hmwk Problem 9.2.\n\n";
                problem2();
                break;
                
            case 4:
                // Drop Lowest Score
                cout << "\nThis is Hmwk Problem 9.3.\n\n";
                problem3();
                break;
            
            case 5:
                // Case Study Modification #1
                cout << "\nThis is Hmwk Problem 9.6.\n\n";
                problem4();
                break;
            
            case 6:
                // Case Study Modification #2
                cout << "\nThis is Hmwk problem 9.7.\n\n";
                problem5();
                break;
        }
    
    } while (choice != QUIT);

    return 0;
}


void meanMedianMode() {
    
    const unsigned short FREQ_SIZE = 10;        // FREQ_SIZE is the number of recorded frequencies in frequency array; 0-9 contains 10 digits, so need 10 frequencies. 0-4 needs 5 freqs.
    
    int *repeatedSet,                           // Pointer to be dynamically allocated. repeatedSet will point to initial memory address.
         setLength,                             // setLength is number of elements (specified by user) in the repeatedSet array.
         maxFreq,                               // maxFreq is the highest value in the frequency array. The digits 0-9 with max frequency are the modes.
         modalSize,                             // modalSize is size of mode array (number of modes plus two).
        *modes,                                 // mode pointer will point to modePtr which is returned from the mode function; it stores {number modes, max freq, mode 1, ... , mode N}.
         frequency[FREQ_SIZE],                  // frequency array stores the frequencies of each digit 0-9 in repeatedSet array.
         numModes;                              // numModes is the number of modes (number of digits that each repeat equal times and repeat the most times).
    
    float arithMean,                            // arithMean is the arithmetic mean or average of the elements in the repeatedSet array.
          medians;                              // medians is the median of the elements in the sorted repeatedSet array.

    
    do {
    cout << "How many elements are in the set? There must be more than one element in the set.\n"; // Ask user to enter the number of elements in the set.
    cin >> setLength;
    } while (setLength < 2);
    
    repeatedSet = new int[setLength];                                       // "new" operator is used to allocate memory to the "repeatedSet" array. How much? setLength (which is an int)
                                                                            // int before [setLength] because the pointer "repeatedSet" is pointing to ints.
    
    unsigned short number = 0;                                              // The following for loop uses array notation on the pointer "repeatedSet" and fills the array.
                                                                            // The array is a set of numbers that repeat beginning with 0. For example, 0, 1, 2, 3, 0, 1, 2, 3, ...
    for (unsigned short count = 0; count < setLength; count++) {            // However, my set is using 0 through 9, and then repeating. The for loop will fill the array with
                                                                            // "setLength" many elements. The variable "number" is initialized at 0, and will increment to 9.
        repeatedSet[count] = number;                                        // Once number == 9, it will be stored in the array, and then be incremented once more; the if statement
        number++;                                                           // will then check to see if number == 10, and if it does, number is reassigned to 0.
        if (number == 10)
            number = 0;
    }
    
    cout << endl;
    
    // printSetArray(repeatedSet, setLength);                                   // Function call to print array after filling array with repeating numbers.

    cout << endl;
    
    arithMean = mean(repeatedSet, setLength);                                   // Function call to calculate the mean.
    
    bool swap;
    unsigned short temp;
    
    do
    {
        swap = false;
        for (unsigned short count = 0; count < (setLength - 1); count++)        // Sort the repeatedSet array.
        {
            if (repeatedSet[count] > repeatedSet[count + 1])
            {
                temp = repeatedSet[count];
                repeatedSet[count] = repeatedSet[count + 1];
                repeatedSet[count + 1] = temp;
                swap = true;
            }
        }
    } while (swap);
    
    // printSetArray(repeatedSet, setLength);                                   // Function call to print array after sorting numbers in ascending order.

    cout << endl;
    
    medians = median(repeatedSet, setLength);                          // Function call to calculate the median.
    
    // Note: For the following for loop, the setLength can either be less than FREQ_SIZE, equal to FREQ_SIZE, or more than FREQ_SIZE.
                                        // If setLength is equal to or more than FREQ_SIZE, there's no problem assigning a value of 1 to each digit 0-9 because there WILL
                                        // be at least 1 of each digit. However, if setLength is less than FREQ_SIZE (which would be kind of pointless, there'd be no modes),
                                        // then there won't be at least 1 of each digit; it could be 0, 1, 2, 3: setLength = 4, but FREQ_SIZE is still 10 (digits 0-9), meaning
                                        // the digits 0-3 would have a frequency of 1, but 4-9 would have a frequency of 0. To get around this problem, the frequency[count] will
                                        // only be assigned the value 1 given that count is less than setLength. For instance, while count is less than 4 (count = 0 through 3).
    
    // Calculate Mode. Mode, max frequency, number of modes.                    // Assign each element in the frequency array to a value of 1. In the next for loop
                                                                                // frequency[0] will represent how many times the first element in repeatedSet repeats,
    for (unsigned short count = 0; count < FREQ_SIZE; count++) {                // frequency[1] will represent how many times the second element in repeatSet repeats, etc.
        
        if (count < setLength)                          // QUESTION: What is the user chooses to have less element than the highest number in the repeatedSet? Suppose I'm using
            frequency[count] = 1;                       // the digits 0 through 9 (10 numbers), but the user wants a set of 5 numbers, so 0, 1, 2, 3, 4. Then not every element can
                                                        // be initialized with a frequency of 1.
        else if (count >= setLength)
            frequency[count] = 0;
    }                                                                           
                                                    // The previous for loop will only say the freq of the element is 1 if count is less than setLength. Ex: setLength = 5, 0-4, so
    int num = 0;                                    // count will go from 0 to 4, and once it hits 4 the loop will stop and not continue to FREQ_SIZE which is 10 (0-9 is 10 digits).
                                                    
    for (unsigned short count = 0; count < (setLength - 1); count++) {          // frequency[num] will store the frequencies of each digit 0-9. frequency[0] will store the
        if (repeatedSet[count] == repeatedSet[count + 1]) {                     // frequency for the digit 0, then frequency[1] will store the frequency for the digit 1. This
            frequency[num]++;                                                   // will continue until frequency[9] begins accumulating; once there are no more nines (9's), then
        }                                                                       // num will increment once more so num = 10, but then the count will be finished and loop is done...?
        else if (repeatedSet[count] != repeatedSet[count + 1]) {
                                                                                // num can only go from 0-9 because there are only those digits for which the frequency array is storing
            num++;                                                              // frequencies (the element in the frequency array is the same as the digit it is counting the freq of).
        }                                                                       // Suppose setLength is 15, then the elements are 0-14, and the last element that can be compared in
    }                                                                           // the repeatedSet would be element 14 with 13; so count stops at 13 which is count < setLength - 1;
                                                                                // 13 < 15 - 1 = 14.

    // printFreqArray(frequency, FREQ_SIZE);                                       // Function call to print frequency array after finding frequencies of each number in the set.
    
    maxFreq = frequency[0];                                                     // Determine the mode(s) by finding the digits with the maximum frequency in repeatedSet array.
    for (unsigned short count = 1; count < FREQ_SIZE; count++) {                // Actually, if any of the digits repeat, the first digit, 0, has to. Zero will be a mode, given
                                                                                // given that it repeats more than one time.
        if (frequency[count] > maxFreq)
            maxFreq = frequency[count];
    }
    
    if (maxFreq > 1)                                                            // The following while loop will determine the number of modes. An if statement is utilized outside the
    {                                                                           // while statement to make sure the max frequency is at least 2 or more (definition of the mode).
        
    int counter = 0;                                                            // loop counter for following while loop
    
    while (frequency[counter] == maxFreq) {                                     // If any of the digits are modes, then zero will be included. It will have the maximum frequency. This while
                                                                                // loop will determine how many of the digits within 0-9 have the max freq.
        counter++;                                                              // Once the digits have less than the maximum frequency, then the while loop will stop iterating.
    }

    numModes = counter;                                                         // Important: numModes is the number of modes and numModes + 2 will give number of elements in
    }                                                                           // modePtr array. Unless you know the size of an array in beginning of program, memory must be
    modalSize = numModes + 2;                                                   // dynamically allocated.

    modes = mode(repeatedSet, setLength, maxFreq, modalSize, numModes);         // Function call to mode function to return the pointer modes; modePtr is now defined only in mode function.
    
    cout << endl << setprecision(2) << fixed;                                   // iomanip is used to have two digits after the decimal point for the mean.
    cout << "Mean: " << arithMean << endl;                                      // Print the mean.
    
    if (setLength % 2 == 0) {
        
    cout << setprecision(1);                                                    // If amount of numbers in set is even, the median will be a decimal, so 1 decimal place.
    cout << "Median: " << medians << endl;                                      // Print the median.
    }
    else if (setLength % 2 == 1) {
        
        cout << setprecision(0);                                                // Need to undo setprecision(2) with setprecision(0). Odd setLength, median will be whole number.
        cout << "Median: " << medians << endl;                                  // Print median.
    }
    
    if (maxFreq > 1) {           // If the max freq is greater than 1, then there will actually be one mode or more than one mode.
    cout << "Mode(s): ";
    
    for (unsigned short index = 2; index < modalSize; index++) {                // This for loop will print the modes stored in the modePtr array.

        cout << modes[index] << " ";
    }
    
    cout << endl;
    cout << "Maximum Frequency: " << modes[1] << endl;                        // Print the maximum frequency using the value stored in modePtr[1].
    cout << "Number of Modes: " << modes[0] << endl;                          // Print the number of modes using the value stored in modePtr[0].
    }
    
    else if (maxFreq == 1) {                                                    // If the max freq is 1, then there are no modes.
        
        cout << "Mode(s): None" << endl;
        cout << "Maximum Frequency: 1" << endl;
        cout << "Number of Modes: 0" << endl;
    }
    
    //delete [] modePtr;                          // Free up the dynamically allocated memory in the modal array.
    //modePtr = 0;                                // Make the modePtr point to null.
    
    delete [] repeatedSet;                      // Free up the dynamically allocated memory.
    repeatedSet = 0;                            // Make the "repeatedSet" pointer point to null. Code may inadvertently try to use pointer to access the memory that was freed,
                                                // but that area of memory will not be accessed if the pointer points to null. Also, there can be errors if delete is accidentally
                                                // called on the pointer again; the delete operator is designed to have no effect on a null pointer.
    cout << endl;
}

// Implement function to calculate the mean of the set.
float mean(int repeatedSet[], int setLength) {
    
    int total = 0;                                                              // "total" will be the sum of the elements in repeatedSet array.
    float arithMean;                                                            // arithMean is the average of the numbers in the set.
    
    for (unsigned short count = 0; count < setLength; count++) {                // for loop is used to sum up all the numbers in repeatedSet array.
        
        total += repeatedSet[count];
    }
    
    arithMean = static_cast<float>(total) / setLength;                               // Calculate the arithmetic mean.
    
    return arithMean;
}

// Implement function to calculate the median of the set.
float median(int repeatedSet[], int setLength) {
    
    float medians;
    
    if (setLength % 2 == 0) {                                                   // If setLength divided by 2 has a zero remainder, the value setLength is even.
        medians = static_cast<float>(repeatedSet[setLength/2] + repeatedSet[(setLength - 1)/2]) / 2;
    }
    else                                                                        // If the value in setLength is not even, then it is odd.
    {
        medians = repeatedSet[setLength/2];
    }
    
    return medians;
}

// Implement function to calculate the mode(s) of the set.
int *mode(int repeatedSet[], int setLength, int maxFreq, int modalSize, int numModes) {
    
    int *modePtr;                                  // Declare pointer "modePtr" which will be dynamically allocated (because we don't know how many modes there will be in repeatedSet).
    
    modePtr = new int[modalSize];                                               // Dynamically allocate memory to modePtr array.
    
    modePtr[0] = numModes;                                                      // modePtr[0] represents the number of modes which is the value stored in count and numModes variables.
    modePtr[1] = maxFreq;                                                       // modePtr[1] represents the maximum frequency which is the number of times the modes repeat.
    
    for (unsigned short index = 2; index < modalSize; index++) {
        
        modePtr[index] = (index - 2);                                           // If there are any modes, then zero will be the first one, and then 1, then 2. So, modePtr[2] = 0,
    }                                                                           // modePtr[3] = 1, modePtr[4] = 2, etc, until index < modalSize.
    
    // If maxFreq is not greater than 1, then modePtr[1] will not be
    // assigned to value of 1, and CANNOT use modePtr[1] when there is no mode.
    
    return modePtr;   
}

void printSetArray(int repeatedSet[], int setLength) {
    
     for(unsigned short count = 0; count < setLength; count++) {                 // This for loop prints the repeatedSet array.

        cout << "repeatedSet[" << count << "]: " << repeatedSet[count] << endl;
    }
}

void printFreqArray(int frequency[], unsigned short FREQ_SIZE) {
    
    for (unsigned short count = 0; count < FREQ_SIZE; count++)                  // This for loop prints the frequency array.
        cout << "frequency[" << count << "]: " << frequency[count] << endl;
}

// Implement function for problem 9.1.
void problem1()
{
    cout << "This program dynamically allocates an array of integers. It declares the amount of memory to be dynamically"
            "\nallocated as a variable and then uses the random number generator to fill the dynamically allocated\n"
            "array.\n\n";
    
    int *integerArray, size = 5;                                                // To point to the numbers stored in dynamically allocated array.
    
    integerArray = dynAlloc(size);                                              // Get an array of 5 random numbers by returning a pointer to this array. Then assign the address to
                                                                                // the pointer integerArray.
    
    for (int count = 0; count < size; count++)                                     // By simply using 5 as an argument of the dynAlloc function, another variable doesn't have to be declared.
        cout << integerArray[count] << endl;                                    // However, if you want to change the amount of space dynamically allocated then you have to find each place
                                                                                // with a 5 and then change it to what you want. (I decided to just declare int size = 5.)
    
    delete [] integerArray;                                                     // Free the memory.
    integerArray = 0;
    
}

// Implementation of dynamic allocation function. Called in problem1 function.
int *dynAlloc(int size) {
    
    int *arr;                                                                   // Array to hold the integers.
    
    if (size <= 0)                                                              // Return null if size is less than or equal to zero. This will immediately terminate the function, and
        return NULL;                                                            // prevent unwanted errors.
    
    arr = new int[size];                                                        // Dynamically allocate the array such that it holds size many integers.
    
    unsigned seed = time(0);                                                    // Get the system time.
    
    srand(seed);                                                                // Seed the random number generator.
    
    for (int count = 0; count < size; count++)                                  // Fill the array with random numbers between 10 and 99.
        arr[count] = 10 + rand() % 90;
    
    return arr;                                                                 // Return a pointer to the array. arr points to where the array integerArray will begin storing its memory.
}

// Implement function for problem 9.2.
void problem2()
{
    int *testScores, amtOfScores;                                               // testScores pointer to be dynamically allocated.
    float average;                                                              // amtOfScores is the number of scores used when testScores pointer is dynamically allocated.
                                                                                // average is the arithmetic mean of the values stored in testScores array.
    
    cout << "This program asks the user to enter any number of test scores, sorts the\n"
            "scores in ascending order, prints the scores, and then averages the test scores.\n\n";
    
    do {                                                                        // Get number of scores to be stored in testScores array (and amount of memory to be dynamically allocated).
        cout << "\nEnter the number of test scores. Do not enter a negative number or 0.\n";      // while loop for input validation.
        cin >> amtOfScores;
    } while (amtOfScores <= 0);
    
    testScores = new int[amtOfScores];                                          // Dynamically allocate memory to testScores array.
    
    cout << "\nEnter all test scores. Press ENTER after each score.\n";
    
    for (unsigned short count = 0; count < amtOfScores; count++) {              // for loop to input scores to array.
        
        do {
            cin >> testScores[count];
        } while (testScores[count] < 0);
    }
    
    sortScores(testScores, amtOfScores);                                        // function call to sort function in ascending order.
    average = averageScores(testScores, amtOfScores);                           // function call to average the scores.
    
    cout << "\nTest Scores:\n";
    cout << "------------\n";
    
    for (int count = 0; count < amtOfScores; count++)                           // Print the test scores. count + 1 is utilized to number the scores when printed.
        cout << count + 1 << ". " << testScores[count] << endl;                 // The element 0 is number 1, the element 1 is number 2, element n is number n + 1.
    
    cout << setprecision(1) << showpoint << fixed;
    cout << "\nAverage Score: " << average << endl << endl;
}

// Implement function bubble sort algorithm to sort testScores array and put into ascending order.
void sortScores(int testScores[], int amtOfScores) {
    
    bool swap;
    unsigned short temp;
    
    do
    {
        swap = false;
        for (int count = 0; count < (amtOfScores - 1); count++)
        {
            if (testScores[count] > testScores[count + 1])
            {
                temp = testScores[count];
                testScores[count] = testScores[count + 1];
                testScores[count + 1] = temp;
                swap = true;
            }
        }
    } while (swap);
}

// Implement function to calculate average of scores in array.
float averageScores(int testScores[], int amtOfScores) {
    
    int total = 0;                                                              // Accumulator variable for contents stored in testScores array.
    float avg;                                                                  // average of the test scores in testScores array.
    
    for (unsigned short count = 0; count < amtOfScores; count++) {              // for loop is used to sum up all the numbers in testScores array.
        
        total += testScores[count];
    }
    
    avg = static_cast<float>(total) / amtOfScores;                              // Calculate the average test score.
    
    return avg;
}

// Implement function for problem 9.3.
void problem3()
{
    cout << "This program is a modification of the previous program that averages the test scores.\n"
            "This time the lowest score of the scores entered will be dropped, and it will not be\n"
            "included in the average.\n\n";
    
    int *testScores, amtOfScores;                                               // testScores pointer to be dynamically allocated.
    float average;                                                              // amtOfScores is the number of scores used when testScores pointer is dynamically allocated.
                                                                                // average is the arithmetic mean of the values stored in testScores array.
    
    do {                                                                        // Get number of scores to be stored in testScores array (and amount of memory to be dynamically allocated).
        cout << "\nEnter the number of test scores. Do not enter a negative number or 0.\n";      // while loop for input validation.
        cin >> amtOfScores;
    } while (amtOfScores <= 0);
    
    testScores = new int[amtOfScores];                                          // Dynamically allocate memory to testScores array.
    
    cout << "\nEnter all test scores. Press ENTER after each score.\n";
    
    for (unsigned short count = 0; count < amtOfScores; count++) {              // for loop to input scores to array.
        
        do {
            cin >> testScores[count];
        } while (testScores[count] < 0);
    }
    
    sortScores(testScores, amtOfScores);                                                // function call to sort function in ascending order.
    average = avgScoresDrop(testScores, amtOfScores);                                   // function call to average the scores. ONLY CHANGE in this program from the previous one is
                                                                                        // inside the average function, the score stored in element 0 of testScores array is not used
    cout << "\nThe following test scores will not include the lowest score.\n";       // in calculating the average, and the total number of elements becomes amtOfScores - 1.
    cout << "\nTest Scores:\n";
    cout << "------------\n";
    
    for (int count = 1; count < amtOfScores; count++)                           // Print sorted scores excluding dropped score. Since count begins with count = 1, numbering
        cout << count << ". " << testScores[count] << endl;                     // begins with count = 1. No need to do numbering by saying count + 1 like previous program.
    
    cout << setprecision(1) << showpoint << fixed;
    cout << "\nAverage Score: " << average << endl << endl;
}

// Implement function to calculate the average of scores after dropping lowest score.
float avgScoresDrop(int testScores[], int amtOfScores) {
    
    int total = 0;                                                              // Accumulator variable for contents stored in testScores array.
    float avg;                                                                  // average of the test scores in testScores array.
    
    // Start at count = 1 gives testScores[1]; this drops lowest test score.
    for (unsigned short count = 1; count < amtOfScores; count++) {              // for loop is used to sum up all the numbers in testScores array, EXCEPT the first score
                                                                                // (which is the lowest, since this function is called after sorting the array); the first
        total += testScores[count];                                             // score is the lowest, and is dropped in this program. To do this, for loop starts with
    }                                                                           // count = 1, which gives testScores[1] which is the 2nd test score, right after the lowest.
    
    avg = static_cast<float>(total) / (amtOfScores - 1);                        // Calculate the average test score after dropping the lowest score.
    
    return avg;
}

// Implement function for problem 9.6.
void problem4()
{
    cout << "This program dynamically allocates memory to an array that stores donations from people,\n"
            "and the program asks the user to input the number of donations being made.\n\n";
    
    int *donations, numDonations;
    
    do {
        cout << "How many donations are being made? Do not enter a negative number.\n";
        cin >> numDonations;
    } while (numDonations < 0);
    
    if (numDonations == 0) {
        
        cout << "\nNot even 1 donation! ...selfish.\n"
                "Returning to main now.\n";
        return;
    }
    
    // Dynamically allocate memory.
    donations = new int[numDonations];
    
    int *arrPtr[numDonations];
    
    cout << "Enter each of the " << numDonations << " donations. Press enter after each amount.\n";
    for (int count = 0; count < numDonations; count++)
        cin >> donations[count];
    
    // Each element of arrPtr is a pointer to int. Make each element point to an element in the donations array.
    for (int count = 0; count < numDonations; count++)
        arrPtr[count] = &donations[count];
    
    // Function call to utilize selection sort algorithm in ascending order.
    arrSelectSort(arrPtr, numDonations);
    
    // Function call to display donations using array of pointers, in sorted order.
    cout << "The donations, sorted in ascending order, are:\n";
    showArrPtr(arrPtr, numDonations);
    
    // Function call to show donations in their original order without resorting.
    cout << "The donations, in their original order, are:\n";
    showArray(donations, numDonations);
    
    // Free memory.
    delete [] donations;
    donations = 0;
}

// Implement function for selection sort algorithm for problem4.
void arrSelectSort(int *arrPtr[], int numDonations) {
    
    int startScan, minIndex, *minElem;
    
    for (startScan = 0; startScan < (numDonations - 1); startScan++) {
        minIndex = startScan;
        minElem = arrPtr[startScan];
        for (int index = startScan + 1; index < numDonations; index++) {
            if (*(arrPtr[index]) < *minElem) {
                minElem = arrPtr[index];
                minIndex = index;
            }
        }
        arrPtr[minIndex] = arrPtr[startScan];
        arrPtr[startScan] = minElem;
    }
}

// Implement function to show array of pointers in ascending order.
 void showArrPtr(int *arrPtr[], int numDonations) {
     
     for (int count = 0; count < numDonations; count++)
         cout << *(arrPtr[count]) << endl;
 }
 
 // Implement function to display donations in original order without resorting.
 void showArray(const int arrPtr[], int numDonations) {
     for (int count = 0; count < numDonations; count++)
         cout << arrPtr[count] << endl;
 } 

 // Implement function for problem 9.7.
void problem5()
{
    cout << "This program is a modification the previous program (the dynamically allocated donations array)."
            "\nIt sorts the donations in descending order instead of ascending order.\n\n";
    
    int *donations, numDonations;
    
    do {
        cout << "How many donations are being made? Do not enter a negative number.\n";
        cin >> numDonations;
    } while (numDonations < 0);
    
    if (numDonations == 0) {
        
        cout << "\nNot even 1 donation! ...selfish.\n"
                "Returning to main now.\n";
        return;
    }
    
    // Dynamically allocate memory.
    donations = new int[numDonations];
    
    int *arrPtr[numDonations];
    
    cout << "Enter each of the " << numDonations << " donations. Press enter after each amount.\n";
    for (int count = 0; count < numDonations; count++)
        cin >> donations[count];
    
    // Each element of arrPtr is a pointer to int. Make each element point to an element in the donations array.
    for (int count = 0; count < numDonations; count++)
        arrPtr[count] = &donations[count];
    
    // Function call to utilize selection sort algorithm in ascending order.
    arr_SelectSort(arrPtr, numDonations);
    
    // Function call to display donations using array of pointers, in sorted order.
    cout << "The donations, sorted in descending order, are:\n";
    show_ArrPtr(arrPtr, numDonations);
    
    // Function call to show donations in their original order without resorting.
    cout << "The donations, in their original order, are:\n";
    show_Array(donations, numDonations);
    
    // Free memory.
    delete [] donations;
    donations = 0;
}

// Implement function for selection sort algorithm for problem5.
void arr_SelectSort(int *arrPtr[], int numDonations) {
    
    int startScan, minIndex, *minElem;
    
    for (startScan = 0; startScan < (numDonations - 1); startScan++) {
        minIndex = startScan;
        minElem = arrPtr[startScan];
        for (int index = startScan + 1; index < numDonations; index++) {
            if (*(arrPtr[index]) > *minElem) {
                minElem = arrPtr[index];
                minIndex = index;
            }
        }
        arrPtr[minIndex] = arrPtr[startScan];
        arrPtr[startScan] = minElem;
    }
}

// Implement function to show array of pointers in descending order.
 void show_ArrPtr(int *arrPtr[], int numDonations) {
     
     for (int count = 0; count < numDonations; count++)
         cout << *(arrPtr[count]) << endl;
 }
 
 // Implement function to display donations in original order without resorting.
 void show_Array(const int arrPtr[], int numDonations) {
     for (int count = 0; count < numDonations; count++)
         cout << arrPtr[count] << endl;
 }