/* 
 * File:   speakerBureau.h
 * Author: Mathew Briguglio
 * Purpose: Structure stores information about speakers in Speakers' Bureau
 * Created on May 18, 2015, 11:17 PM
 */

#ifndef SPEAKERBUREAU_H
#define	SPEAKERBUREAU_H

struct SpeakerBureau
{
    std::string name;                                                           // Speaker's name.
    std::string number;                                                         // Speaker's telephone number.
    std::string topic;                                                          // Topic of speech.
    float fee;                                                                  // Fee required.
};

#endif	/* SPEAKERBUREAU_H */

