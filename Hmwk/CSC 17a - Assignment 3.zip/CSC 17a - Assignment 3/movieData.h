/* 
 * File:   movieData.h
 * Author: Mathew Briguglio
 * Purpose: MovieData struct stores information about a movie
 * Created on May 17, 2015, 8:59 PM
 */

#ifndef MOVIEDATA_H
#define	MOVIEDATA_H

struct MovieData
{
    std::string title;                                                          // The movie title.
    std::string director;                                                       // The movie's director.
    int releaseYear;                                                            // The year the movie was released.
    int runTime;                                                                // The movie's run time in minutes.
};

#endif	/* MOVIEDATA_H */

