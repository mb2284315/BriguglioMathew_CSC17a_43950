/* 
 * File:   softDrinks.h
 * Author: Mathew Briguglio
 * Purpose: SoftDrinks struct stores drink names, costs, and number of cans left
 * Created on May 17, 2015, 10:15 PM
 */

#ifndef SOFTDRINKS_H
#define	SOFTDRINKS_H

struct SoftDrinks
{
    std::string drinkName;                                                      // Name of soft drink.
    int drinkCost;                                                              // Cost of soft drink.
    int numDrinks;                                                              // Number of cans left in machine.
};

#endif	/* SOFTDRINKS_H */

