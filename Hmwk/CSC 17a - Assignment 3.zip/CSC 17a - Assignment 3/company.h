/* 
 * File:   company.h
 * Author: Mathew Briguglio
 * Purpose: Store Corporate Data
 * Created on May 23, 2015, 3:26 AM
 */

#ifndef COMPANY_H
#define	COMPANY_H

struct Company
{
    char division[10];                                                          // The division of the company; East, West, North, or South.
    char quarter;                                                               // Fiscal quarter; 1, 2, 3, or, 4.
    float sales[4];                                                             // Quarterly sales; an array of floats will store the sales for 4 quarters.
};

#endif	/* COMPANY_H */

