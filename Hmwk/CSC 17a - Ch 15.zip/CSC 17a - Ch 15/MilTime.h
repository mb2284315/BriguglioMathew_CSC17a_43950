
#ifndef MILTIME_H
#define	MILTIME_H

#include "Time.h"
using namespace std;
#include <iostream>

class MilTime : public Time
{
    public:
        MilTime();
        MilTime(signed int, signed int);
        void setTime(signed int, signed int);
        void getHour();
        void getStandHr();
    protected:
        signed int milHours;
        signed int milSeconds;
        string ampm;

};

#endif	/* MILTIME_H */

