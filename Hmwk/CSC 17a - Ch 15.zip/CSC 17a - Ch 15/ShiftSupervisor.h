
#ifndef SHIFTSUPERVISOR_H
#define	SHIFTSUPERVISOR_H
#include "Employee.h"
using namespace std;

class ShiftSupervisor : public Employee
{
    public:
        ShiftSupervisor(string, int, int, float, float);
        float getAnnualSalary();
        float getAnnualProductionBonus();
        void setAnnualSalary(float);
        void setAnnualProductionBonus(float);
        void showInfo();
    protected:
        float annual_salary;
        float annual_production_bonus;

};

#endif	/* SHIFTSUPERVISOR_H */

