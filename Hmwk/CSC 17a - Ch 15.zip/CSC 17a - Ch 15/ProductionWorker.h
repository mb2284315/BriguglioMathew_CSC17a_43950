

#ifndef PRODUCTIONWORKER_H
#define	PRODUCTIONWORKER_H

#include "Employee.h"

class ProductionWorker : public Employee
{
    public:
        ProductionWorker(string, int, int, int, float);
        int getShift();
        float getHourlyPayRate();
        void setShift(int);
        void setHourlyPayRate(int);
        virtual void showInfo();
    protected:
        int shift;
        float hourlypayrate;
};

#endif	/* PRODUCTIONWORKER_H */

