

#ifndef TEAMLEADER_H
#define	TEAMLEADER_H

using namespace std;
#include "ProductionWorker.h"

class TeamLeader : ProductionWorker
{
    public:
        TeamLeader(string, int, int, int, float, float, float, float);
        float getMonthlyBonusAmount();
        float getTrainingHours();
        float getNumOfTrainingHoursAttended();
        void setMonthlyBonusAmount(float);
        void setTrainingHours(float);
        void setNumOfTrainingHoursAttended(float);
        void showInfo();
    protected:
        float monthly_bonus_amount;
        float training_hours;
        float num_of_training_hours_attended;
};

#endif	/* TEAMLEADER_H */

