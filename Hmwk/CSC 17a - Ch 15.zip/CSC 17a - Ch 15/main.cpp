/* 
 * File:   main.cpp
 * Author: Mathew Briguglio
 * Purpose: CSC 17a - Ch. 15
 * Created on May 29, 2015, 1:33 AM
 */

#include <cstdlib>
#include <iostream>
#include "ProductionWorker.h"
#include "ShiftSupervisor.h"
#include "TeamLeader.h"
#include "MilTime.h"
#include "TimeClock.h"

using namespace std;
int Menu();
void C15P1();
void C15P2();
void C15P3();
void C15P4();
void C15P5();

int main(int argv,char *argc[])
{
    int selection;
    
    do{ 
        selection=Menu(); // get input
        
        switch(selection) // menu selection to select which homework problem
        {
        case 1: 
            C15P1();// Chapter 15 Programming Challenges Problem 1
            break;  
        case 2: 
            C15P2();// Chapter 15 Programming Challenges Problem 2
            break;
        case 3: 
            C15P3();// Chapter 15 Programming Challenges Problem 3
            break;  
        case 4:
            C15P4();// Chapter 15 Programming Challenges Problem 4
            break;
        case 5: 
            C15P5();// Chapter 15 Programming Challenges Problem 5
            break;  
        default: 
            break;
        } 
    }while(selection<6); // loop until invalid selection 
    cout << endl;
    return 0;
}

int Menu()
{
    int selection;
    cout<< "1. Problem 1"<<endl;
    cout<< "2. Problem 2"<<endl;
    cout<< "3. Problem 3"<<endl;
    cout<< "4. Problem 4"<<endl;
    cout<< "5. Problem 5"<<endl;
    cout<< "Type anything else to exit \n"<<endl;
    cin >> selection;
    return selection;
}

void C15P1()
{
    int employee_number, hire_date, shift = 0;
    string employee_name;
    float hourlypayrate;
    
    cout << "Please enter the employee name: ";
    cin >> employee_name;
    
    cout << "Please enter the employee number: ";
    cin >> employee_number;
    
    cout << "Please enter the date of hire: ";
    cin >> hire_date;
    
    while (shift !=1 && shift !=2)
    {
        cout << "Please enter the shift (1 for day, 2 for night): ";
        cin >> shift; 
    }
    
    cout << "Please enter the hourly pay rate: ";
    cin >> hourlypayrate;
    
    ProductionWorker* pw = new ProductionWorker(employee_name, employee_number, hire_date, shift, hourlypayrate);
    
    cout << "current info: ";
    pw->showInfo();
    cout << endl;
    
    cout << "Lets change things" << endl;
    
    pw->setHDate(12201991);
    pw->setHourlyPayRate(100);
    pw->setName("Matt");
    pw->setNum(1);
    pw->setShift(2);
    pw->showInfo();
    cout << endl;
    
    delete pw;
}

void C15P2()
{
    int employee_number, hire_date;
    string employee_name;
    float annual_salary, annual_production_bonus;
    
    cout << "Please enter the employee name: ";
    cin >> employee_name;
    
    cout << "Please enter the employee number: ";
    cin >> employee_number;
    
    cout << "Please enter the date of hire: ";
    cin >> hire_date;
    
    cout << "Please enter the annual salary: ";
    cin >> annual_salary;
        
    cout << "Please enter the annual production bonus: ";
    cin >> annual_production_bonus;
    
    ShiftSupervisor* ss = new ShiftSupervisor(employee_name, employee_number, hire_date, annual_salary, annual_production_bonus);
    
    cout << "current info: ";
    ss->showInfo();
    cout << endl;
    
    cout << "Lets change things" << endl;
    
    ss->setHDate(12201991);
    ss->setName("Matt");
    ss->setNum(1);
    ss->setAnnualSalary(200000);
    ss->setAnnualProductionBonus(25);

    ss->showInfo();
    cout << endl;
    
    delete ss;
}

void C15P3()
{
    int employee_number, hire_date, shift = 0;
    string employee_name;
    float hourlypayrate, monthly_bonus_amount, training_hours, num_of_training_hours_attended;
    
 
    cout << "Please enter the employee name: ";
    cin >> employee_name;
    
    cout << "Please enter the employee number: ";
    cin >> employee_number;
    
    cout << "Please enter the date of hire: ";
    cin >> hire_date;
    
    cout << "Please enter the hourly pay rate: ";
    cin >> hourlypayrate;
    
    cout << "Please enter the monthly bonus amount: ";
    cin >> monthly_bonus_amount;
    
    cout << "Please enter the training hours: ";
    cin >> training_hours;
    
    cout << "Please enter the number of training hours: ";
    cin >> num_of_training_hours_attended;
    
    TeamLeader* ss = new TeamLeader(employee_name, employee_number, hire_date, shift, hourlypayrate, monthly_bonus_amount, training_hours, num_of_training_hours_attended);
    
    cout << "current info: ";
    ss->showInfo();
    cout << endl;

    cout << "Lets change things" << endl;
    
    ss->setMonthlyBonusAmount(35634);
    ss->setNumOfTrainingHoursAttended(56);
    ss->setTrainingHours(80);
    ss->showInfo();
    cout << endl;
    
    delete ss;
}

void C15P4()
{
    MilTime* time = new MilTime(1600, 30);
    time->getHour();
    time->getStandHr();
    time->setTime(1200,25);
    time->getHour();
    time->getStandHr();
    cout << endl;
    delete time;
    
}

void C15P5()
{
    TimeClock* time = new TimeClock(525,950);
    cout << endl;
    time->compute();
    
    TimeClock* time2 = new TimeClock(1525,1900);
    cout << endl;
    time2->compute();
    
    TimeClock* time3 = new TimeClock(800,1300);
    cout << endl;
    time3->compute();
    
    TimeClock* time4 = new TimeClock(845,920);
    cout << endl;
    time4->compute();
    

    delete time;
    delete time2;
    delete time3;    
    delete time4;

}



