
#include "Employee.h"

using namespace std;

Employee::Employee(string name, int num, int hdate) 
{
    this->employee_name = name;
    this->employee_number = num;
    this->hire_date = hdate;
}

string Employee::getName()
{
    return this->employee_name;
}

int Employee::getHDate()
{
    return this->hire_date;
}

int Employee::getNum()
{
    return this->employee_number;
}

void Employee::setName(string name)
{
    this->employee_name = name;
}

void Employee::setHDate(int hdate)
{
    this->hire_date = hdate;
}

void Employee::setNum(int num)
{
    this->employee_number = num;
}

